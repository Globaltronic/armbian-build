#!/bin/bash


# 2019-07-18 : Test SPI0 native with EEPROM SPI 25LC04

file_name=$(basename $0)
echo "0.01" > /tmp/ver_${file_name}


# check SPIDEV present
if [ ! -c /dev/spidev0.0 ]; then
	echo "Error: SPI device 0 not found"
	echo "please enable spidev and spi-add-cs1 on armbian-config"
	echo -ne "SPI_EEP;KO"
	exit 1
fi

# check spidev_test present

if [ ! -f $HOME/spidev-test/spidev_test ]; then
	echo "Error: spidev_test program not present / compiled"
	echo -ne "SPI_EEP;KO"
	exit 2
fi

home_user=$HOME

# send eeprom read command
eeprom_rdata=`sudo /bin/bash -c "${home_user}/spidev-test/spidev_test -D /dev/spidev0.0 -p '\x03\x00\x00'"`

eeprom_rbyte=`echo ${eeprom_rdata} | sed -nr "s/\r//;s/.*RX\s+\|\s+00\s+00\s+([A-F0-9]{2}).*/\1/gp"`

if [ "${eeprom_rbyte}" != "00" ]; then
	echo -ne "SPI_EEP;${eeprom_rbyte};OK"
else
	echo -ne "SPI_EEP;KO"
fi

