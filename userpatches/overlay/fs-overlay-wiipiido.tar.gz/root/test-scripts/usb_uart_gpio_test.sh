#!/bin/bash


# 2019-07-18 : Test USB UART bridge CP2108 native with Silicon Labs driver.... Beware its instalation
# 2019-07-26 : Modified version for NBIOT testing
# 2019-07-26 : Modified version for NBIOT testing



file_name=$(basename $0)
sudo /bin/bash -c "echo \"0.03\" > /tmp/ver_${file_name}"


# check if driver is installed properley
silabs_driver_st=`sudo /bin/bash -c "/sbin/modinfo cp210x | grep 'Silicon Labs'"`

if [ "$silabs_driver_st" == "" ]; then
	echo "Driver Not installed"
	echo "Please install Silicon Labs driver"
	exit 1
fi



# check serial_test install

if [ ! -f $HOME/serial_test/serial_test ]; then
	echo "Serial Program Test Not installed"
	exit 2
fi


# check gpio_serial_toggle test program

if [ ! -f $HOME/cp210x_gpio_test/cp210x_gpio_example ]; then
	echo "GPIO Serial Program Test Not compiled"
	exit 3
fi


# wake up modem by PWR_KEY

if [ ! -f /sys/class/gpio/gpio144/value ]; then
	sudo /bin/bash -c "echo 144 > /sys/class/gpio/export" 
fi

sudo /bin/bash -c "echo out > /sys/class/gpio/gpio144/direction" 
sudo /bin/bash -c "echo 0 > /sys/class/gpio/gpio144/value" 
/bin/sleep 1	
sudo /bin/bash -c "echo 1 > /sys/class/gpio/gpio144/value" 
/bin/sleep 1	


# Get all serial ports fired by the driver



#configure serial ports
#/bin/stty speed 115200 -F /dev/ttyUSB0 cs8 -cstopb -parenb
#/bin/stty speed 9600 -F /dev/ttyUSB1 cs8 -cstopb -parenb
#/bin/stty speed 9600 -F /dev/ttyUSB2 cs8 -cstopb -parenb
#/bin/stty speed 9600 -F /dev/ttyUSB3 cs8 -cstopb -parenb

/bin/stty speed 115200 -F /dev/ttyUSB0 
/bin/stty speed 9600 -F /dev/ttyUSB1 -echo -icanon time 50 min 0
/bin/stty speed 9600 -F /dev/ttyUSB2 -echo -icanon time 50 min 0
/bin/stty speed 9600 -F /dev/ttyUSB3 -echo -icanon time 50 min 0

/bin/stty -F /dev/ttyUSB0 
/bin/stty -F /dev/ttyUSB1
/bin/stty -F /dev/ttyUSB2
/bin/stty -F /dev/ttyUSB3 




# fire up serial test for all four ports
echo "Test Port 0"
$( /bin/bash -c "$HOME/serial_test/nbiot_test /dev/ttyUSB0 > /tmp/nbiot_result" ) 
#echo "NBiot Test Resut $nbiot_test"

nbiot_result=$( sed -nr "s/\r\n//;s/.*(USBUART;(\S+);(\S+);OK).*/\1/p" /tmp/nbiot_result );

if [ "$nbiot_result" == "" ]; then
	/bin/bash -c "$HOME/serial_test/serial_test /dev/ttyUSB0"
else
#	nbiot_tty=$( echo $nbiot_test | sed -nr "s/\r//;s/.*\s*((\S+);(\S+);(\S+);OK).*/\1/p" )
	echo "NBIOT: ${nbiot_result}"
fi

echo "Test Port 1"
/bin/bash -c "$HOME/serial_test/serial_test /dev/ttyUSB1"
echo "Test Port 2"
/bin/bash -c "$HOME/serial_test/serial_test /dev/ttyUSB2"
echo "Test Port 3"
/bin/bash -c "$HOME/serial_test/serial_test /dev/ttyUSB3"

#execute GPIO in loop the test

while true; do

	
	read -t 1 -n 1 -r q
	
	/bin/bash -c "$HOME/cp210x_gpio_test/cp210x_gpio_example"
	
	echo "Press 'q' to exit"

	if [ "$q" == "q" ]; then
		break
	fi
done	

