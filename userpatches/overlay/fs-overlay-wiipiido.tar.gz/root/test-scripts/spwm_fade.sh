#!/bin/bash

# 2019-07-17: demo program for SPWM, period 2.5mS / 400Hz: 


myself=`basename $0`
echo 0.1 > /tmp/ver_${myself}


period="$1"

usage(){
	echo "`basename $0` period"
	echo "period 0 - 1000 ms"
}

if [ "$1" == "" ]; then
	usage
	exit 1
fi

if [ ! -f  "$HOME/test-scripts/spwm_test.sh" ]; then
	echo "Error: spwm_test script not found"
	echo "Install in the test script dir"
	exit 2
fi


sudo /bin/bash -c "$HOME/test-scripts/spwm_test.sh $1 50"

let i=5

while [ $i -lt 95 ]; do
	sudo  /bin/bash -c "$HOME/test-scripts/spwm_test.sh --keep $i"
	let i=$((i+5))
	/bin/sleep 1
done

let i=95

while [ $i -gt 0 ];do 
	sudo /bin/bash -c "$HOME/test-scripts/spwm_test.sh --keep $i"
	let i=$((i-5))
	sleep 1
done
