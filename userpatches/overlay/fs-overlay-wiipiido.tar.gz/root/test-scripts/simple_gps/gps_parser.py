RMCDAT = {
    'strType': None,
    'fixTime': None,
    'status': None,
    'lat': None,
    'latDir': None,
    'lon': None,
    'lonDir': None,
    'groundSpeed': None,
    'groundCourse': None,
    'date':None,
    'mode':None
}

GGADAT = {
    'strType': None,
    'fixTime': None,
    'lat': None,
    'latDir': None,
    'lon': None,
    'lonDir': None,
    'fixQual': None,
    'numSat': None,
    'horDil': None,
    'alt': None,
    'altUnit': None,
    'galt': None,
    'galtUnit': None,
    'DPGS_updt': None,
    'DPGS_ID': None
}

def parseGNRMC(gpsComponents):
    for i, k in enumerate(
                ['strType', 'fixTime', 'status', 'lat', 'latDir',
                 'lon', 'lonDir', 'groundSpeed', 'groundCourse',
                 'date','mode']):
        RMCDAT[k] = gpsComponents[i]

    return RMCDAT

def parseGNGGA(gpsComponents):
    for i, k in enumerate(
                ['strType', 'fixTime',
                'lat', 'latDir', 'lon', 'lonDir',
                'fixQual', 'numSat', 'horDil',
                'alt', 'altUnit', 'galt', 'galtUnit',
                'DPGS_updt', 'DPGS_ID']):
        GGADAT[k] = gpsComponents[i]

    return GGADAT
