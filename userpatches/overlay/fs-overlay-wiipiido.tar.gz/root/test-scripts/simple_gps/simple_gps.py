import time
import json
import logging

import gps_parser
import gps_bus
import gps_commands

gpsReadInterval = 0.1
LOG = logging.getLogger()

# SOURCE
# https://stackoverflow.com/questions/28867795/reading-i2c-data-from-gps

# GUIDE
# http://ava.upuaut.net/?p=768

def parseResponse(gpsLine):
    global lastLocation
    gpsChars = ''.join(chr(c) for c in gpsLine)
    if "*" not in gpsChars:
        return False

    gpsStr, chkSum = gpsChars.split('*')
    gpsComponents = gpsStr.split(',')
    gpsStart = gpsComponents[0]
    chkVal = 0
    for ch in gpsStr[1:]: # Remove the $
        chkVal ^= ord(ch)
    if (chkVal == int(chkSum, 16)):
        if (gpsStart == "$GNGGA"):
            result = gps_parser.parseGNGGA(gpsComponents)
            print json.dumps(result, indent=2)
        elif (gpsStart == "$GNRMC"):
            result = gps_parser.parseGNRMC(gpsComponents)
            print json.dumps(result, indent=2)

def readGPS():
    c = None
    response = []
    try:
        while True: # Newline, or bad char.
            c = gps_bus.read()
            if c == 255:
                return False
            elif c == 10:
                break
            else:
                response.append(c)
        #print ''.join(chr(c) for c in response)
        parseResponse(response)
    except IOError:
        time.sleep(0.5)
        gps_bus.connect()
    except Exception, e:
        print e
        LOG.error(e)

def main():
    gps_bus.connect()
    #gps_commands.coldStart()
    #time.sleep(10)
    #gps_commands.defaultConfiguration()
    while True:
        readGPS()
        time.sleep(gpsReadInterval)

if __name__ == "__main__":
    main()
