import smbus

BUS = None
address = 0x42
bus_number = 0

def send(msg):
    for i in msg:
        BUS.write_byte(address, i)

def connect():
    global BUS
    BUS = smbus.SMBus(bus_number)

def read():
    return BUS.read_byte(address)
