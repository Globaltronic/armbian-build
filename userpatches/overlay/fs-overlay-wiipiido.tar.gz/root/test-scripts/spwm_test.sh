#!/bin/bash


# 2019-07-17 Test script for A64 S-PWM 
# 2019-07-22 Added super user for executing scripts

myself=`basename $0`
echo 0.2 > /tmp/ver_${myself}

usage (){

	echo "Usage";
	echo "`basename $0` period dutty_cycle"
	echo "period: 1 ~ 1000 ms / --keep : change only dutty-cycle"
	echo ":dutty cycle: 0 ~ 100% "
	
}


period="$1"
dutty_cycle="$2"


if [ "$1" == "" ]; then
	usage
	exit 1
fi

if [ "$2" == "" ]; then
	usage
	exit 2
fi


# initialized PWM module
if [ ! -f /sys/class/pwm/pwmchip0/pwm0/period ]; then
	sudo /bin/bash -c "echo 0 > /sys/class/pwm/pwmchip0/export"
fi 


 
# calculate period
fperiod="$( bc <<< "$period*10" )"
let mperiod=$( echo "$fperiod/1" | bc )

if [ $mperiod -gt 0  ] || [ $mperiod -lt 10000 ]; then
	
	nsec_period="$( bc <<< "$period * 1000000" )"
	
	insec_period=$( echo "$nsec_period/1" | bc )

	
	if [ "$period" == "--keep" ]; then 
		insec_period=`cat /sys/class/pwm/pwmchip0/pwm0/period` 
	fi

	echo "Period : $insec_period"
else
	usage
	exit 3

fi

# compute dutty cycle according to period
if [ $dutty_cycle -gt 0  ] || [ $dutty_cycle -lt 100 ]; then
	
	sysfs_dutty="$( bc <<< "$insec_period * $dutty_cycle/100")"	
	isysfs_dutty=$( echo "$sysfs_dutty/1" | bc )

	echo "dutty : $isysfs_dutty"
else
	usage
	exit 4
fi



# set PWM period

if [ "$period" != "--keep" ]; then 
	sudo /bin/bash -c "echo ${insec_period} > /sys/class/pwm/pwmchip0/pwm0/period"
	sudo /bin/bash -c "echo "inversed" > /sys/class/pwm/pwmchip0/pwm0/polarity"
	sudo /bin/bash -c "echo "normal" > /sys/class/pwm/pwmchip0/pwm0/polarity"
	sudo /bin/bash -c "echo 1 > /sys/class/pwm/pwmchip0/pwm0/enable"
fi

sudo /bin/bash -c "echo ${isysfs_dutty} > /sys/class/pwm/pwmchip0/pwm0/duty_cycle"



