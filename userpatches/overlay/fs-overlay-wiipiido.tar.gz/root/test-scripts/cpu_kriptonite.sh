#!/bin/bash

# 2019-06-17: Burning test for CPU and its internal guts... using crytography


my_name=`basename $0`
echo "0.01" > /tmp/ver_${my_name}

while true; do openssl speed -multi 4; done


