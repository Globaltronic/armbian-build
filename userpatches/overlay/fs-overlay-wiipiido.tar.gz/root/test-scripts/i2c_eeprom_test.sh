#!/bin/bash


# 2019-07-18 : Test USB SPI brigde + GPIO with EEPROM SPI 25LC040

file_name=$(basename $0)
echo "0.01" > /tmp/ver_${file_name}





if [ ! -f /sys/devices/platform/soc/1c2b000.i2c/i2c-1/new_device ]; then
	echo "I2C1 not enabled. Go to armbian-config and enable i2c1"
	echo -ne "I2C1_EEP;KO"
	exit 1
fi


sudo /bin/bash -c "echo 24c256 0x50 > /sys/devices/platform/soc/1c2b000.i2c/i2c-1/new_device"

if [ -f /sys/devices/platform/soc/1c2b000.i2c/i2c-1/1-0050/eeprom ]; then

	# write eeprom
	sudo /bin/bash -c "echo 'DEADBE' > /sys/devices/platform/soc/1c2b000.i2c/i2c-1/1-0050/eeprom"
	
	# read first line of written data and skip the rest of the eeprom... takes a while to read the full contents..	
	eeprom_data=`sudo /bin/bash -c "head -n 1 /sys/devices/platform/soc/1c2b000.i2c/i2c-1/1-0050/eeprom"`

	if [ "$eeprom_data" == "DEADBE" ]; then
		echo -ne "I2C1_EEP;OK"
	else
		echo -ne "I2C1_EEP;KO"
	fi	


	# delete device from sysfs
	sudo /bin/bash -c "echo 0x50 > /sys/devices/platform/soc/1c2b000.i2c/i2c-1/delete_device"
fi 



