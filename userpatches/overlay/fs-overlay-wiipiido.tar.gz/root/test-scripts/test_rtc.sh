#!/bin/bash
# Test RTC not in loop fashion.

my_name=$(basename "$0")
echo "0.01" > "/tmp/ver_${my_name}"

usage(){
	echo -e "Usage: $(basename "$0") [dev]  "
}

/sbin/hwclock > /dev/null 2>&1

if [ "$?" == "0" ]; then

	#uses file descriptor
	if [ "$1" != "" ]; then
        rtc_cmd=$(/sbin/hwclock -w -f "$1")
		rtc_cmd=$(/sbin/hwclock -r -f "$1")

		if [ "$?" != "0" ]; then
			usage
		fi
	else
        rtc_cmd=$(/sbin/hwclock -r)

		if [ "$?" != "0" ]; then
			usage
		fi
	fi

    rtc_check=$(echo "${rtc_cmd}" | sed -nr "s/(.*)([0-9]{2}:[0-9]{2}:[0-9]{2})(.*)/\2/p")

	if [ "$rtc_check" != "" ]; then
		echo -ne "rtc;OK"
	else
		echo -ne "rtc;KO"
	fi
else
	echo -ne "rtc;KO"
fi
