#!/bin/bash

# Auth: Globaltronic


test_mpg123='which mpg123'
if [ "$test_mpg123" != "Error" ]; then

	eval echo $( mpg123 -a default  http://icecast.commedia.org.uk:8000/wcr.mp3 )
else
	echo "Install mpg123 to allow stream"
	echo "apt install mpg123"
fi
