#!/bin/bash

# 2019-07-18 : Test 1-Wire Temperature sensor for A64 

file_name=$(basename $0)
echo "0.01" > /tmp/ver_${file_name}

sensor_data=`cat /sys/bus/w1/devices/28-*/w1_slave`

raw_val=`echo $sensor_data | sed -nr "s/\r//;s/.*t=([0-9]{,5})/\1/pg"`

if [ "$raw_val" != "" ]; then 
	echo -ne "$raw_val"
else
	echo -ne "temp;KO"
	exit 1
fi
