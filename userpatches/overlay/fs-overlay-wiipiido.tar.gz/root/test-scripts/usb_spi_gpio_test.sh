#!/bin/bash
# 2019-07-22: Program to test USB SPI Bridge GPIO Pins as outputs
# 2019-07-25: added loop test as standard for toggle GPIO's
# 2019-08-06: Use experimental custom driver program 

file_name=$(basename $0)
echo "0.04" > /tmp/ver_${file_name}

mode=$1

usage(){
	echo "$(basename $0) mode [gpio]"
	echo "modes:"
	echo "--loop: loop"
	echo "--single: single gpio"
}

# check available scripts and binary from USB SPI bridge - obsolete available driver can handle this
if [ ! -f $HOME/MCP2210_linux_library/runme.sh ]; then
	echo "MCP2210 Interface lib not found"
	exit 1
fi

if [ ! -f $HOME/usb_spi_gpio_test/usb_spi_test ]; then
	echo "MCP2210 Interface lib not compiled. Run Makefile"
	exit 2
fi

if [ "$mode" == "--loop" ]; then
	test_mode=0
elif [ "$mode" == "--single" ]; then
	test_mode=1
else
	usage
	exit 3
fi

hidraw_msg=`/bin/bash -c "$HOME/MCP2210_linux_library/runme.sh"`

hidraw_dev=`echo ${hidraw_msg} | sed -nr "s/\r//;s/.*\"(\S+)\"/\1/p"`

# Write GPIO's with 1 / 0 and check board to get result.
if [  -c ${hidraw_dev} ]; then
	home_user=$HOME
		
	let i=1
	while [ $i -le 8 ]; do

		sudo /bin/bash -c "$home_user/usb_spi_gpio_test/usb_spi_test -D $hidraw_dev -P $i -V 1"
        	/bin/sleep 1
			
		sudo /bin/bash -c "$home_user/usb_spi_gpio_test/usb_spi_test -D $hidraw_dev -P $i -V 0"
        	/bin/sleep 1
	
		let i=$i+1

		if [ "$test_mode" == "1" ]; then
			break;
		fi

	done
else
	echo "No HIDRAW found. Execute runme.sh"
	exit 4
fi
