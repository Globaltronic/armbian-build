// Program to read /write and read back the eeprom via USB SPI MCP2210 bridge and use GPIOS
// 2019-07-29
// gcc usb_spi_test.c -lc -o usb_spi_test

// 2019-08-06:  First release candidate
// 2019-08-08: 3 TODO's and Added debug routines.
  

// TODO: 
//	--> Implement a header file...  OK
//	--> add usage function. OK 
//	--> getopts on argv ... OK
// 	--> add option for debug via above method ..ok
//	--> Implement writing to external eeprom ... WIP
// 	--> Develop a kernel driver from this source

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>

#include "usb_spi_test.h"



int main(int argc, char **argv)
{
	int fd = 0;
	int io_res = 0;
	int i = 0;
	int tryouts = 0;
	unsigned char tx_data[1024];
	unsigned char rx_data[1024];
	char rdata[256] = {0,};
	int xmit_length = 0;
        int spi_mode = 0;
        int spi_speed = 0;
        int actcsval = 0;
        int idlecsval = 0;
        int gpcsmask = 0;
        int cs2datadly = 0;
        int data2datadly = 0;
        int data2csdly = 0;

	int gpio_num = 0;
	int gpio_out = -1; 
	int gpio_opt = -1;

	int my_gpio_dir = 0;
	int my_gpio_mask = 0;
	int my_gpio_out_val = 0;

	int my_gpio_in_val = 0;

	uint8_t spi_bus_rel_ext_status = 0;	
	uint8_t spi_bus_curr_owner = 0;	

	uint8_t rdsr_reg = 0;
	
	// Replace this with getopts 
	int c = 0;
	char mspi_dev[256];
	char mgpio_pin[256];
	char mgpio_val[256];


	int spi_dev_ext_eep 	= -1; 
	int spi_dev_present 	= -1;
	int spi_dev_port_no 	= -1;
	int spi_dev_port_mode 	= -1;
	int spi_dev_debug_mode 	= 0;
	int spi_dev_ext_eep_wren = 0; 	

	if (argc > 1 ){


	//2019-08-07 : using getopts argument system

#ifdef USE_GETOPTS

	while( (c = getopt( argc, argv, "wvSsdD:P:V:D:" )) != -1 ){
	

		switch(c){
			
			
		
			case 's':
			case 'S': // invoke external SPI EEPROM
				spi_dev_ext_eep = 1;
			break;
			case 'w':
			case 'W':
				spi_dev_ext_eep_wren = 1;
			break;
			case 'D':	
				sprintf( mspi_dev,  "%s", optarg);
				spi_dev_present = 1;
			break;
			
			case 'p':			
			case 'P': // port num, default as input			
				sprintf(mgpio_pin, "%s", optarg);
				spi_dev_port_no = 1;
				spi_dev_port_mode = 1;
			break;
			
			case 'V': // Output mode if specified
				sprintf(mgpio_val, "%s", optarg);
				spi_dev_port_mode = 0;
			break;

			case 'd':
			case 'v':
				spi_dev_debug_mode = 1;
			break;

				

			default:
			usage();
			return 1;


		}
	
	} 	

#else

		if (argc >= 3){

			// get gpio Descr
			printf("NUmberArgs: %d", argc );
			//if ( ( strcmp(argv[2], "") != 0 )  )
			{
 
				gpio_num =  atoi(argv[2]);
					
				if ( gpio_num >=0 && gpio_num<=8 ){
					

				
					printf ("\n GPIO Argv_2 Selected: %d\n " , gpio_num);
				//	printf ("\n Arguments: %d\n " , argc );

					// is output required?
					if (argc ==4){
				//		printf("\n Dir: %s", argv[3]);
			
							
							gpio_out = atoi(argv[3]);
							gpio_out &= 0x01;
							printf("\n .. as output %d\n", gpio_out);
						
						gpio_opt = 0;
					}else{
							printf("\n .. as input\n");

						gpio_opt = 1;

					}		
					

				}else{
					
					printf (" Usage: ");
					printf (" --> Output: ./program <dev> <gpio_num> [1/0] ");
					printf (" --> Input: ./program <dev> <gpio_num> ");
					exit(1);


				}

			}
 	}

#endif

#ifdef USE_GETOPTS

		printf ("USB SPI Device : %s\n" , mspi_dev);
		fd = open( mspi_dev, O_RDWR );


#else
		printf ("USB SPI Device : %s\n" , argv[1]);
		fd = open( argv[1], O_RDWR );

#endif
		

		if (fd > 0 ){
			printf("SPI Device openend\n");

#ifdef USE_GETOPTS
		
		if(spi_dev_present == 1 ){	
#endif
			char rdata[256] = {0,};
			//---------------------- Read internal EEPROm Data - sanity / self check
			
			io_res = read_eeprom(fd, 0x00, &rdata[0]);
			io_res = read_eeprom(fd, 0x01, &rdata[1]);
			io_res = read_eeprom(fd, 0x02, &rdata[2]);
			io_res = read_eeprom(fd, 0x03, &rdata[3]);
		
			printf( "Data: %02x %02x  %02x %02x\n",  rdata[0], rdata[1], rdata[2], rdata[3]);

			//-------------------------- prepare xmit data - 
			spi_mode		= 0;
                        spi_speed		= 1000000;
                        actcsval		= 0xFFFE; // choose chip select CS0
                        idlecsval		= 0xFFFF;  // .. as output high
                        gpcsmask		= 0x0001;  // mask gpio  for CS0 for SPI EEPROM
                        cs2datadly		= 0;
                        data2datadly		= 0;
                        data2csdly		= 0;
                        xmit_length		= 4;
#ifdef USE_GETOPTS
		}
#endif
#ifdef TEST_USB_SPI_SANITY
                        
#ifdef USE_GETOPTS
	if (  spi_dev_present ==1 )
	{
#endif
			// 2019-08-08: Force debug in this particular mode
			spi_dev_debug_mode = 1;
			//-------------------------- Get Dev Status		
			st_devstatus mDevStatus;
			get_dev_status(fd, &mDevStatus, spi_dev_debug_mode); 
		

			//-------------------------- Get SPI chip info

			printf("\n>------Read SPI Chip Settings-------<\n");
	
			st_dev_settings mDevSettings;
			get_dev_curr_settings(fd, &mDevSettings, spi_dev_debug_mode);



			//-------------------------- Save SPI chip info
			printf("\n>------Write SPI Chip Settings-------<\n");
			set_dev_curr_settings(fd, &mDevSettings, spi_dev_debug_mode);

			// -------------------------- Read Back SPI info
			printf("\n>------Read Back SPI Chip Settings-------<\n");
	
			st_dev_settings mSavedDevSettings;
			get_dev_curr_settings(fd, &mSavedDevSettings, spi_dev_debug_mode);

						
			//-------------------------- Test Writing SPI parameters for xmit
			printf("\n>------Write  SPI XMIT Settings-------<\n");
			st_spi_xmit_settings mSPIXmitSettings;
			
			mSPIXmitSettings.baudrate			= (uint32_t)spi_speed;
    			mSPIXmitSettings.spi_mode_flags			= spi_mode;
    			mSPIXmitSettings.data2xmit			= (uint16_t)xmit_length;
    			mSPIXmitSettings.idle_cs_sel			= (uint16_t)idlecsval;
    			mSPIXmitSettings.active_cs_sel			= (uint16_t)actcsval;
    			mSPIXmitSettings.cs2data_cs_dly			= (uint16_t)cs2datadly;
    			mSPIXmitSettings.data2data_dly			= (uint16_t)data2datadly;
    			mSPIXmitSettings.data2cs_dly			= (uint16_t)data2csdly;
				
			set_spi_xmit_params(fd, &mSPIXmitSettings, spi_dev_debug_mode);

			puts("\n");

		
			//-------------------------- Test Read Back SPI parameters for xmit


			printf("\n>------Read back  SPI XMIT Settings-------<\n");
			st_spi_xmit_settings mSPIXmitReadSettings;
			get_spi_xmit_params(fd, &mSPIXmitReadSettings, spi_dev_debug_mode);

			puts("\n");

#ifdef USE_GETOPTS
	}
#endif


#endif
			
			//-------------------------- Xmit data from external EEPROM
#ifdef TEST_SPI_EEPROM_WRITE
	
#ifdef USE_GETOPTS
	if (spi_dev_ext_eep == 1 && spi_dev_present == 1 && spi_dev_ext_eep_wren == 1)
	{
#endif
		printf("\n>------Write external SPI EEPROM - CS0 -------<\n");
		
		// CMD SPI EEPROM WREN 

		printf("\n SPI XMIT Write Enable \n");

		tx_data[0] = 0x06; // CMD SPI EEPROm WREN ( Write enable)
		xmit_length = 2; // page size + CMD's

		actcsval	= 0xFFFE;
		idlecsval	= 0xFFFF;
		gpcsmask	= 0x0001;

		
		io_res = spi_data_xmit(fd, tx_data, rx_data, xmit_length ,
				spi_mode, spi_speed, actcsval, idlecsval, 
				gpcsmask, cs2datadly,data2csdly, data2datadly , spi_dev_debug_mode 			
			);
	

		if (io_res < 0 ){
		
				printf ("\n !!!! Abort SPI Transfer  !!!! \n");	
				cancel_curr_spi_xmit(fd, &spi_bus_rel_ext_status, &spi_bus_curr_owner , spi_dev_debug_mode);
				printf ("\n --> Cancel SPI Transfer Request Status: %d \n", spi_bus_rel_ext_status );	
				printf ("\n --> Cancel SPI Transfer Current  Owner: %d \n", spi_bus_curr_owner);	
		}


		usleep(10000);
	

		// CMD SPI EEPROM  
		tryouts = 20;
		do{
	
			printf("\n SPI XMIT Read Status Register \n");
			tx_data[0] = 0x05; // CMD SPI EEPROm RDSR ( Read Status Register)
			xmit_length = 2; // page size + CMD's
	
			actcsval	= 0xFFFE;
			idlecsval	= 0xFFFF;
			gpcsmask	= 0x0001;
	
			
			io_res = spi_data_xmit(fd, tx_data, rx_data, xmit_length ,
					spi_mode, spi_speed, actcsval, idlecsval, 
					gpcsmask, cs2datadly,data2csdly, data2datadly , spi_dev_debug_mode 			
				);
		
	
			if (io_res < 0 ){
			
					printf ("\n !!!! Abort SPI Transfer !!!! \n");	
					cancel_curr_spi_xmit(fd, &spi_bus_rel_ext_status, &spi_bus_curr_owner , spi_dev_debug_mode);
					printf ("\n --> Cancel SPI Transfer Request Status: %d \n", spi_bus_rel_ext_status );	
					printf ("\n --> Cancel SPI Transfer Current  Owner: %d \n", spi_bus_curr_owner);	
	
	
			}
			
			printf("\n SPI XMIT from SPI EEPROM RDSR returned %d ", io_res);
				
			print_row_buffer(&rx_data[1], 1, 8);

			rdsr_reg = (uint8_t) (rx_data[1] & 0xFF);


			
			printf("\n  EEPROM RDSR Value %02x ", rdsr_reg);


			if ( (rdsr_reg & 0x2) == 0x02  ){

				printf("\n ----> Write Enable from SPI EEPROM RDSR ON ----<\n");
				break;
			}

			usleep(10000);
		}
		while (--tryouts >=0 );

			
			// Write enable latch is on 		
			if ( (rdsr_reg & 0x2) == 0x02  ){

				printf("\n ----> Write Enable from SPI EEPROM RDSR ON ----<\n");
				printf("\n ----> Write Seq Data to  SPI EEPROM  ----<\n");

				
					

				tx_data[0] = 0x02; // CMD SPI EEPROm WRITE
				tx_data[1] = 0x00; // CMD SPI EEPROm Address
				
				// fill seq data
				
				for (i = 2; i < 258; i++){

					tx_data[i] = (uint8_t) (257 -i); // CMD SPI EEPROm RDSR ( Read Status Register)
				
				}
				


				xmit_length = 258; // page size + CMD's
	
				actcsval	= 0xFFFE;
				idlecsval	= 0xFFFF;
				gpcsmask	= 0x0001;
	
				
				io_res = spi_data_xmit(fd, tx_data, rx_data, xmit_length ,
						spi_mode, spi_speed, actcsval, idlecsval, 
						gpcsmask, cs2datadly,data2csdly, data2datadly , spi_dev_debug_mode 			
					);
			
	
				if (io_res < 0 ){
				
						printf ("\n !!!! Abort SPI Transfer !!!! \n");	
						cancel_curr_spi_xmit(fd, &spi_bus_rel_ext_status, &spi_bus_curr_owner , spi_dev_debug_mode);
						printf ("\n --> Cancel SPI Transfer Request Status: %d \n", spi_bus_rel_ext_status );	
						printf ("\n --> Cancel SPI Transfer Current  Owner: %d \n", spi_bus_curr_owner);	
	
	
				}


				printf("\n ----> Check WIP Status from SPI EEPROM RDSR ----<\n");

				// check WIP status
				tryouts = 20;
				do{
					
					printf("\n SPI XMIT Read Status Register after Write OPs\n");
					tx_data[0] = 0x05; // CMD SPI EEPROm RDSR ( Read Status Register) - 
					xmit_length = 2; // page size + CMD's
			
					actcsval	= 0xFFFE;
					idlecsval	= 0xFFFF;
					gpcsmask	= 0x0001;
			
					
					io_res = spi_data_xmit(fd, tx_data, rx_data, xmit_length ,
							spi_mode, spi_speed, actcsval, idlecsval, 
							gpcsmask, cs2datadly,data2csdly, data2datadly , spi_dev_debug_mode 			
						);
				
			
					if (io_res < 0 ){
					
							printf ("\n !!!! Abort SPI Transfer !!!! \n");	
							cancel_curr_spi_xmit(fd, &spi_bus_rel_ext_status, &spi_bus_curr_owner , spi_dev_debug_mode);
							printf ("\n --> Cancel SPI Transfer Request Status: %d \n", spi_bus_rel_ext_status );	
							printf ("\n --> Cancel SPI Transfer Current  Owner: %d \n", spi_bus_curr_owner);	
			
			
					}
					
					printf("\n SPI XMIT from SPI EEPROM RDSR returned %d ", io_res);
						
					print_row_buffer(&rx_data[1], 1, 8);
	
					rdsr_reg = (uint8_t) (rx_data[1] & 0xFF);
					
					printf("\n  EEPROM RDSR Value WR-WIP: %02x \n", rdsr_reg);
	
	
					usleep(10000);
	


				}while( ((rdsr_reg & 0x01) == 0x01) &&  (--tryouts >=0));


				if ( (rdsr_reg & 0x01) == 0x01  ){
					printf("\n !!!!! WIP from SPI EEPROM RDSR TIMEOUT !!!!!!\n");
				}else{

					printf("\n ----> Finished Write SPI XMIT to SPI EEPROM ----<\n");
				}
				

			}else
			{
				printf("\n !!!!! Write Enable from SPI EEPROM RDSR TIMEOUT !!!!!!\n");
				//return 2;
			}
		


			printf("\n ----> Finished SPI XMIT from SPI EEPROM RDSR returned ----<\n");
			print_row_buffer(&rdsr_reg, 1, 8);

			

#ifdef USE_GETOPTS
	}
#endif



#endif



#ifdef TEST_SPI_EEPROM_READ					

#ifdef USE_GETOPTS
	if (spi_dev_ext_eep == 1 && spi_dev_present == 1){
#endif


			printf("\n>------Read external SPI EEPROM - CS0 -------<\n");
			
			tx_data[0] = 0x03; // CMD SPI EEPROm Read 
			tx_data[1] = 0x00; // CMD SPI EEPROm Address
			xmit_length = 258; // page size + CMD's

            		actcsval	= 0xFFFE;
                        idlecsval	= 0xFFFF;
                        gpcsmask	= 0x0001;
			

			io_res = spi_data_xmit(fd, tx_data, rx_data, xmit_length ,
				spi_mode, spi_speed, actcsval, idlecsval, 
				gpcsmask, cs2datadly,data2csdly, data2datadly , spi_dev_debug_mode 			
			);
			
			if (io_res < 0 ){
		
				printf ("\n !!!! Abort SPI Transfer !!!! \n");	
				cancel_curr_spi_xmit(fd, &spi_bus_rel_ext_status, &spi_bus_curr_owner , spi_dev_debug_mode);
				printf ("\n --> Cancel SPI Transfer Request Status: %d \n", spi_bus_rel_ext_status );	
				printf ("\n --> Cancel SPI Transfer Current  Owner: %d \n", spi_bus_curr_owner);	


			}


	
			printf("\n SPI XMIT from SPI EEPROM returned %d ", io_res);
			
			print_row_buffer(&rx_data[2], 256, 8);
#ifdef USE_GETOPTS
	}
#endif

#endif



#ifdef TEST_SPI_GPIOS
					
#ifdef USE_GETOPTS
		if (spi_dev_port_no == 1 && spi_dev_present == 1)
		{	

			gpio_num =  atoi(mgpio_pin);
					
			if ( gpio_num >=0 && gpio_num<=8 ){
				printf ("\n GPIO opt Selected: %d\n " , gpio_num);
			}else{
				usage();
				return 2;
			}


			if ( spi_dev_port_mode == 0   ){
				
				gpio_out = atoi( mgpio_val );
				gpio_out &= 0x01;
				printf("\n .. as output %d\n", gpio_out);
				gpio_opt = 0;
			}else{
				printf("\n .. as input\n");
				gpio_opt = 1;	
			}



#endif

			if( gpio_opt >= 0 ){

				printf("\n>------SET GPIO Direction -------<\n");
				
				printf (" \n GPIO Selected: %d " , gpio_num);
				
				if (gpio_opt == 0)	
					printf(" .. as output %d\n", gpio_out);
				else
					printf(" ..as input");
				
				
				// Get GPIO index direction and corresponding mask
				my_gpio_dir =  ( (int) (  (uint16_t) (gpio_opt & 0x1)  << (uint16_t)gpio_num ) & 0x01FF );
				my_gpio_mask = ( (int)  (( 0x1<< (uint16_t)gpio_num)) & 0x01FF);

				//-------------------------- Set GPIO direction
				printf("\nSet desired GPIO Direction \n");
				printf("\n--> Desired GPIO number: %04x \n", my_gpio_dir);
				printf("\n--> Desired GPIO mask: %04x \n", my_gpio_mask);
		
				// set MCP2210 gpio direction
				io_res = gpio_direction(fd, my_gpio_dir , my_gpio_mask , spi_dev_debug_mode );

				printf("\n>------SET GPIO OUTPUTS -------<\n");
				printf("\n>------   if any      -------<\n");
			
				// Turn on desired outputs.. if any ... TESTING
	#ifdef TEST_SET_GIO_RAM	
				printf("\nSet desired GPIO Outputs in Ram .. Testing \n");
				if (gpio_out == 1){
					gpio_set_pin_val(fd, 0xFFFF, spi_dev_debug_mode);
					usleep(500000);
				}
				else{
					gpio_set_pin_val(fd,0x0000, spi_dev_debug_mode);
					usleep(500000);
				}
	#endif
		


				//-------------------------- Set GPIO output value if any
				// 2019-08-06: it is required casting this ????? Seriously... its funtional and is required for kernel portability
				my_gpio_out_val = (int)( (uint16_t) ((gpio_out & 0x1) << gpio_num) & 0x01FF);
				//my_gpio_out_mask = (int) ((uint16_t) (  my_gpio_mask & 0x01FF ));

				printf("\nSet desired GPIO Outputs \n");
				printf("\n--> Desired GPIO output val: %04x \n", my_gpio_out_val);
				printf("\n--> Desired GPIO mask: %04x \n", my_gpio_mask);

				//  2019-08-06 : Does  not turn on individual pins... test all pins below
				if (gpio_opt == 0){	
					gpio_out_value(fd, my_gpio_out_val, my_gpio_mask , spi_dev_debug_mode );
				}
				
							
				// Test gpio_ou_val function sanity - OK with all pins on.... weird
	#ifdef TEST_GPIO_OUT_VALUE
				if (gpio_out == 1){
					gpio_out_value(fd, 0x0102, 0x0102 , spi_dev_debug_mode);
					usleep(500000);
				}
				else{
					gpio_out_value(fd,0x0000, 0x0102, spi_dev_debug_mode );
					usleep(500000);
				}
	#endif
	
				//-------------------------- Get GPIO input value if any
				printf("\n>------SET GPIO Inputs -------<\n");
				printf("\n>------   if any      -------<\n");
			

	#ifdef TEST_GPIO_IN_VALUE
				gpio_get_pin_val(fd, (uint16_t*)&my_gpio_in_val, spi_dev_debug_mode);
							
				
				printf("\nGet desired GPIO Inputs - Testing \n");
				printf("\n--> Desired GPIO input val: %04x \n", my_gpio_in_val);
				
	#endif
				if (gpio_opt == 1){

					gpio_in_value ( fd, &my_gpio_in_val, my_gpio_mask, spi_dev_debug_mode );
					
	
			
					printf("\nGet desired GPIO Input\n");
					printf("\n--> Desired GPIO input val: %04x \n", my_gpio_in_val);

					
				}
			

			}
				
#ifdef USE_GETOPTS
	}
#endif			


#endif



			close(fd);

		}else{

			perror("\n\tUnable to open device");
		}

				
	
	}
	else{

		printf( " Error: no /dev/hidrawX supplied" );
	}



	
	return 0;
}

/**
* @brief Send and Receive function and state machine with error handling 
*
* @param fd
* @param tx_data
* @param rx_data
* @param xmit_length
* @param spi_mode
* @param spi_speed
* @param act_cs_val
* @param idle_cs_val
* @param gpcsmask
* @param cs2datadly
* @param data2datadly
* @param data2csdly
*
* @return 
*/
int spi_data_xmit(int fd, unsigned char *tx_data,
                                        unsigned char *rx_data, int xmit_length,
                                        int spi_mode, int spi_speed,
                                        int act_cs_val, int idle_cs_val, int gpcsmask,
                                        int cs2datadly, int data2datadly, int data2csdly, int debug_sw)
{

	int ictn, io_res, inum_xmits, idata_xmit_rem, ixmit_timeout, tryouts, itmp = 0;
	int idata_tx_idx, idata_rx_idx = 0;
	uint8_t spi_xmit_addr_code, force_exit = 0;
	uint8_t xmit_part_len_tx, xmit_part_len_rx = 0;
	uint8_t spi_bus_rel_ext_status, spi_bus_curr_owner = 0;	


	st_dev_settings st_setup;
	st_devstatus st_status;
	st_spi_xmit_settings st_spi_xmit_setup;
	
	
	// get device status
	io_res = get_dev_status(fd, &st_status, debug_sw);
	
	if (io_res != 0){
		return -1;
	}	

	// get current chip device settings
	io_res = get_dev_curr_settings(fd, &st_setup, debug_sw);
	if ( io_res != 0 ){
		return -2;
	}

	// config chip select needed for external eeprom (any)
	for ( ictn = 0; ictn < DEV_NGPIOS; ictn++){

		if (gpcsmask & (1<< ictn) ){
			st_setup.pin_opt[ictn] = GPN_PIN_ALTFUNC_1;
		}
	}


	// set current chip settings. - gpios 
	io_res = set_dev_curr_settings(fd, &st_setup, debug_sw);

	if ( io_res != 0 ){
		return -3;
	}


	// recheck current settings
	io_res = get_dev_curr_settings(fd, &st_setup, debug_sw);
	if ( io_res != 0 ){
		return -8;
	}
	

	// fill the required parameters for SPI xmit 
	st_spi_xmit_setup.baudrate		= (uint32_t) spi_speed;
	st_spi_xmit_setup.spi_mode_flags	= spi_mode;
	st_spi_xmit_setup.data2xmit		= (uint16_t) xmit_length;
	st_spi_xmit_setup.idle_cs_sel		= (uint16_t) idle_cs_val;
	st_spi_xmit_setup.active_cs_sel		= (uint16_t) act_cs_val;
	st_spi_xmit_setup.cs2data_cs_dly	= (uint16_t) cs2datadly;
	st_spi_xmit_setup.data2data_dly		= (uint16_t) data2datadly;
	st_spi_xmit_setup.data2cs_dly		= (uint16_t) data2csdly;

	// setup the needed SPI xmit param
	io_res = set_spi_xmit_params(fd, &st_spi_xmit_setup, debug_sw);
	
	if (io_res != 0){

		//check status chip dev if it is available
		itmp = get_dev_status(fd, &st_status, debug_sw);
		if ( itmp != 0 ){
		
			return -4;
		}
		
		return -5;
	} 
	
	// sanity check for the xmit parameters
	io_res = get_spi_xmit_params(fd,&st_spi_xmit_setup, debug_sw);
	
	if ( io_res != 0 ){
		
		return -7;
	} 

	// xmit the current data
	// --> setup timeout 
	ixmit_timeout 	= 1; // for 1MHz 
	idata_xmit_rem 	= xmit_length;	 

	// compute to 60 byte data len 
	if( ( xmit_length % MCP2210_MAX_SPI_DATA_LEN )  == 0 ){
		inum_xmits = ( xmit_length / MCP2210_MAX_SPI_DATA_LEN  );
	}else{
		inum_xmits = ( xmit_length / MCP2210_MAX_SPI_DATA_LEN  ) + 1;
	}

	idata_tx_idx	= 0;
	idata_rx_idx	= 0;
	force_exit	= 0;
	tryouts		= 0;
	
	// send data using SPI device
	for (ictn = 0; ictn < inum_xmits; ictn++){

		while( (tryouts < MCP2210_XMIT_TRYOUTS) && (force_exit != 1) ){
			
			// get ready to send blocks of data
			if (tryouts == 0){
				
				// for less than 60 byes
				if (idata_xmit_rem <= MCP2210_MAX_SPI_DATA_LEN)
				{
					xmit_part_len_tx = (uint8_t) idata_xmit_rem;
					idata_xmit_rem = 0; 	//reset for next block

				}else{
					xmit_part_len_tx = MCP2210_MAX_SPI_DATA_LEN;
					idata_xmit_rem -= MCP2210_MAX_SPI_DATA_LEN;
				}
	
			}
		
			// perform data transmission
			io_res = xmit_spi_data(fd, &tx_data[idata_tx_idx], &rx_data[idata_rx_idx],
				&xmit_part_len_tx, &xmit_part_len_rx, &spi_xmit_addr_code, debug_sw);
				
			// error
			if (io_res < 0){
				
				printf("\n----> XMIT HW ERROR  <----\n");
			
				if (debug_sw){

					printf("\nspi_xmit_addr_code = 0x%02X\n", spi_xmit_addr_code);
					printf("\n -->xmit_part_len_tx = %d\n", xmit_part_len_tx);
					printf("\n -->xmit_part_len_tx = %d\n", xmit_part_len_tx);
					printf("\n -->idata_tx_idx = %d\n", idata_tx_idx);
					printf("\n -->idata_rx_idx = %d\n", idata_rx_idx);
					printf("\n -->tryouts = %d\n", tryouts);
					printf("\n -->inum_xmits = %d\n", inum_xmits);
					printf("\n -->idata_xmit_rem= %d\n", idata_xmit_rem);
					printf("\n<---- XMIT HW ERROR  ---->\n");
				}

				cancel_curr_spi_xmit(fd, &spi_bus_rel_ext_status, &spi_bus_curr_owner, debug_sw);
			
				printf ("\n --> Cancel XMIT SPI Transfer Request Status: %d \n", spi_bus_rel_ext_status );	
				printf ("\n --> Cancel XMIT SPI Transfer Current  Owner: %d \n", spi_bus_curr_owner);	

				itmp = get_dev_status(fd, &st_status, debug_sw);

				if (itmp != 0){
					return -6;
				}
			
				return io_res;

	
			} 

				
			// check SPI xmit addr status machine
			switch(spi_xmit_addr_code){
				
				// data xmited but no rx_data present
				case DEV_SPI_XMIT_NORXDATA:
					

					if (tryouts == 0){
						idata_tx_idx += xmit_part_len_tx; // increment tx len
							
						// data is lower / higher than 60 bytes
						if (idata_xmit_rem <= MCP2210_MAX_SPI_DATA_LEN)
                        			{
                            				xmit_part_len_tx = (uint8_t)idata_xmit_rem;
			                	        idata_xmit_rem = 0; // reset 
                        			}
                        			else
                        			{
		                        		xmit_part_len_tx = MCP2210_MAX_SPI_DATA_LEN;
                	           		 	idata_xmit_rem  -= MCP2210_MAX_SPI_DATA_LEN;
                        			}

					}

					usleep(ixmit_timeout * 1000);
	
				break;
				// rx data is on buffer 
				case DEV_SPI_XMIT_RXDATA:
				case DEV_SPI_XMIT_RXDATAEND:
					
					idata_rx_idx += xmit_part_len_rx; // increment tx len ???? Nope is rx upon having available data.
					if( spi_xmit_addr_code == DEV_SPI_XMIT_RXDATA ){


						idata_tx_idx += xmit_part_len_tx; // increment tx len ???? Nope is rx upon having available data.
						if (idata_xmit_rem <= MCP2210_MAX_SPI_DATA_LEN){	
							xmit_part_len_tx = (uint8_t)idata_xmit_rem;
							idata_xmit_rem = 0; // reset counter

						}else{
							xmit_part_len_tx = MCP2210_MAX_SPI_DATA_LEN;
							idata_xmit_rem -= MCP2210_MAX_SPI_DATA_LEN;

						}
						ictn++; // skip to next packet 
					}else{
						force_exit = 1;	// end of data???
					}


				break;
	
				case DEV_SPI_XMITONGOING:
					// chip busy in xmit data
		
				break;		



			}
		tryouts++;		
		} 	
	tryouts = 0;
	force_exit = 0;
		
	}

	return 0;
}


/**
* @brief Transmit / Receive chunks of data only - used by function above 
*
* @param fd
* @param tx_data
* @param rx_data
* @param p_data_len_tx
* @param p_data_len_rx
* @param p_res_code
*
* @return error_code
*/
int xmit_spi_data(int fd, unsigned char *tx_data,
                    unsigned char *rx_data, uint8_t *p_data_len_tx,
                    uint8_t *p_data_len_rx, uint8_t *p_res_code, int debug_sw)
{
    unsigned char bufftx[MCP2210_HID_REPORT_LEN];
    unsigned char buffrx[MCP2210_HID_REPORT_LEN];
    int io_res = 0;

	// Copy user data
	memcpy(&bufftx[4], tx_data, *p_data_len_tx);

	if (*p_data_len_tx > MCP2210_MAX_SPI_DATA_LEN)
	{
		bufftx[1] = MCP2210_MAX_SPI_DATA_LEN;
	}else{
		bufftx[1] = *p_data_len_tx;
	}

	// send CMD to xFER data
	bufftx[0] = CMD_XMITSPIDATA;
	

	

	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_XMIT_SPI_DATA	
		printf(" Error: %d", io_res ); 
#endif	
		return -1;	
	}else{
#ifdef DEBUG_XMIT_SPI_DATA
		printf( "\nXMIT Data Wrote: %d bytes\n", io_res );
#endif
	}


	if (debug_sw){
  		print_row_buffer(bufftx, MCP2210_HID_REPORT_LEN, 10);
	}

	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);
	
	if (io_res < 0){
#ifdef DEBUG_XMIT_SPI_DATA	
		printf(" Error: %d", io_res ); 
#endif	
		return -1;	
	}else{
#ifdef DEBUG_XMIT_SPI_DATA
		printf( "\nXMIT Data Read: %d bytes\n", io_res );
#endif
	}

	if (debug_sw){
  		print_row_buffer(buffrx, MCP2210_HID_REPORT_LEN, 10);
	}

	// Check error
	if (buffrx[1] != DEV_NOERR)
	{
		if (buffrx[1] == DEV_SPI_XMITONGOING)
		{
			// SPI is xmit - retry
			*p_res_code   = DEV_SPI_XMITONGOING;
			*p_data_len_rx   = 0;
			return 0;
		}
#ifdef DEBUG_XMIT_SPI_DATA
	printf("\n XMIT SPI data - CMD status ERROR");
#endif
        	return -2;
	}
	

    	{
	 
 	// copy the added result code and the rx data 
	*p_res_code		= buffrx[3];
	*p_data_len_rx		= buffrx[2];
	
	// bufrx[2]  --> Number bytes are available to read
	if ( (buffrx[3] == DEV_SPI_XMIT_RXDATAEND) ||
		(buffrx[3] == DEV_SPI_XMIT_RXDATA) )
		memcpy(rx_data, &buffrx[4], buffrx[2]);
    	}
	

	return 0;
}

/**
* @brief get chip dev status 
*
* @param fd
* @param ptsdevstatus
*
* @return error_code
*/
int get_dev_status(int fd, st_devstatus *ptsdevstatus, int debug_sw){

	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
	int io_res = 0;
	uint16_t *ptmp;

	// Send CMD get status
	bufftx[0] = CMD_GETSTATUS;

	
	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_GET_STATUS	
		printf(" Error: %d", io_res ); 
		perror ("\n DEV Status op read fail\n");
#endif	
		return -1;	
	}else{
#ifdef DEBUG_GET_STATUS
		printf( "\nDEV Status Wrote %d bytes\n", io_res );
#endif
	}



    	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);
	if (io_res < 0){
#ifdef DEBUG_GET_STATUS	
		printf(" Error: %d", io_res ); 
		perror ("\n DEV Status op write fail\n");
#endif	
		return -2;	
	}else{
#ifdef DEBUG_GET_STATUS
		printf( "\nDEV Status Read %d bytes\n", io_res );
#endif
	}

	if ( debug_sw ){
		print_row_buffer(buffrx, MCP2210_HID_REPORT_LEN, 10);
	}
	
	if ( buffrx[1] != DEV_NOERR  ){
		
		printf("\nDEV Status CMD Error\n");
		//cancel_curr_spi_xmit(fd);
		return -3;
	}
	
	// fill struct data
	ptsdevstatus->dat_usb_xmited = buffrx[6];
	ptsdevstatus->dat_usb_to_xmit = buffrx[7];
	ptmp = (uint16_t *) &buffrx[8];
	ptsdevstatus->dat_xmited = le16toh(*ptmp);
	ptsdevstatus->usb_cmd_wait = buffrx[10];
	ptsdevstatus->spi_state = buffrx[10];



#ifdef DEBUG_GET_STATUS


	if (debug_sw ){
		printf ( "\n\nCMD GET Status Result\n" );
		printf ( "\n-->SPI Data to Xmit: %d bytes\n", ptsdevstatus->dat_usb_to_xmit  );
		printf ( "\n-->SPI USB Data Xmited: %d bytes\n", ptsdevstatus->dat_usb_xmited  );
		printf ( "\n-->SPI Data Xmited: 0x%x \n", ptsdevstatus->dat_xmited  );
		printf ( "\n-->USB SPI Wait Xmit: 0x%02x \n", ptsdevstatus->usb_cmd_wait  );
		printf ( "\n-->SPI Status: 0x%02x \n", ptsdevstatus->spi_state  );	
	}
#endif


	return 0;
}

/**
* @brief Get SPI engine Xmit params 
*
* @param fd
* @param p_st_xmit_setup
*
* @return 
*/
int get_spi_xmit_params(int fd, st_spi_xmit_settings *p_st_xmit_setup, int debug_sw )
{
	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
	int io_res = 0;
	uint16_t * p_uint;
	uint32_t * p_long;

	// Send CMD to get SPI xmit parameters
	bufftx[0] = CMD_GETSPITRANSACTION;
		
	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_SPI_GET_PARAMS
		printf(" Error: %d", io_res ); 
		perror ("\n SPI get params write op fail\n");
#endif	
		return -1;	
	}else{
#ifdef DEBUG_SPI_GET_PARAMS
		printf( "\n SPI get params wrote %d bytes\n", io_res );
#endif
	}

	if (debug_sw){
		print_row_buffer (bufftx, MCP2210_HID_REPORT_LEN, 10);
	}

	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){	
#ifdef DEBUG_SPI_GET_PARAMS
		printf(" Error: %d", io_res ); 
		perror ("\n SPI get params read op fail\n");
#endif	
		return -2;	
	}else{
#ifdef DEBUG_SPI_GET_PARAMS
		printf( "\n SPI get params read %d bytes\n", io_res );
#endif
	}
	
	if (debug_sw){
		print_row_buffer (buffrx, MCP2210_HID_REPORT_LEN, 10);
	}
	
	if ( buffrx[1] != DEV_NOERR ){
		printf("\nSPI get params CMD error\n");
		return -3;
	}	

	// get the parameters from the correct offset
	p_long				= (uint32_t *) &buffrx[4];
	p_st_xmit_setup->baudrate	= le32toh(*p_long);
	
	p_uint				= (uint16_t *)  &buffrx[8];
	p_st_xmit_setup->idle_cs_sel 	= le16toh(*p_uint);
	
	p_uint				= (uint16_t *)  &buffrx[10];
	p_st_xmit_setup->active_cs_sel	= le16toh(*p_uint);

	p_uint				= (uint16_t *) &buffrx[12];
	p_st_xmit_setup->cs2data_cs_dly = le16toh(*p_uint);

	p_uint				= (uint16_t *) &buffrx[14];
	p_st_xmit_setup->data2cs_dly 	= le16toh(*p_uint);

	p_uint				= (uint16_t *) &buffrx[16];
	p_st_xmit_setup->data2data_dly	= le16toh(*p_uint);

	p_uint				= (uint16_t *) &buffrx[18];
	p_st_xmit_setup->data2xmit	= le16toh(*p_uint);

	p_st_xmit_setup->spi_mode_flags = buffrx[20];


#ifdef DEBUG_SPI_GET_PARAMS

if (debug_sw){
	printf ( "\nCMD GET current Settings Result\n" );	
	printf("\n-->SPI Mode: %d\n", p_st_xmit_setup->spi_mode_flags);
	printf("\n-->SPI Data to Xmit: %d bytes\n", p_st_xmit_setup->data2xmit);
	printf("\n-->SPI Speed: %d\n", p_st_xmit_setup->baudrate);
	printf("\n-->SPI Idle CS : 0x%04X\n", p_st_xmit_setup->idle_cs_sel);
	printf("\n-->SPI Active CS: 0x%04X\n", p_st_xmit_setup->active_cs_sel);
	printf("\n-->SPI CS2Data delay: %d\n", p_st_xmit_setup->cs2data_cs_dly);
	printf("\n-->SPI Data2Data delay: %d\n", p_st_xmit_setup->data2data_dly);
	printf("\n-->SPI Data2CS delay: %d\n", p_st_xmit_setup->data2cs_dly);
}

#endif


	return 0;
}


/**
* @brief set SPI mechanism Xmit params 
*
* @param fd
* @param p_st_xmit_setup
*
* @return 
*/
int set_spi_xmit_params(int fd, st_spi_xmit_settings *p_st_xmit_setup, int debug_sw )
{


	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
	int io_res = 0;
	
	
	// Write SPI params in the correct offsets
	bufftx[4] = (uint8_t)(p_st_xmit_setup->baudrate & 0xFF);
	bufftx[5] = (uint8_t)((p_st_xmit_setup->baudrate & 0xFF00) >> 8);
	bufftx[6] = (uint8_t)((p_st_xmit_setup->baudrate & 0xFF0000) >> 16);
	bufftx[7] = (uint8_t)((p_st_xmit_setup->baudrate & 0xFF000000) >> 24);
	
	bufftx[8] = (uint8_t)(p_st_xmit_setup->idle_cs_sel & 0xFF);
	bufftx[9] = (uint8_t)((p_st_xmit_setup->idle_cs_sel & 0xFF00) >> 8);
	
	bufftx[10] = (uint8_t)(p_st_xmit_setup->active_cs_sel & 0xFF);
	bufftx[11] = (uint8_t)((p_st_xmit_setup->active_cs_sel & 0xFF00) >> 8);
	
	bufftx[12] = (uint8_t)(p_st_xmit_setup->cs2data_cs_dly & 0xFF);
	bufftx[13] = (uint8_t)((p_st_xmit_setup->cs2data_cs_dly & 0xFF00) >> 8);
	
	bufftx[14] = (uint8_t)(p_st_xmit_setup->data2cs_dly & 0xFF);
	bufftx[15] = (uint8_t)((p_st_xmit_setup->data2cs_dly & 0xFF00) >> 8);
	
	bufftx[16] = (uint8_t)(p_st_xmit_setup->data2data_dly & 0xFF);
	bufftx[17] = (uint8_t)((p_st_xmit_setup->data2data_dly & 0xFF00) >> 8);
	
	bufftx[18] = (uint8_t)(p_st_xmit_setup->data2xmit & 0xFF);
	bufftx[19] = (uint8_t)((p_st_xmit_setup->data2xmit & 0xFF00) >> 8);
	
	bufftx[20] = p_st_xmit_setup->spi_mode_flags;
	
	// send CMD to set SPI Xmit parameters
 	bufftx[0] = CMD_SETSPITRANSACTION;
    	bufftx[1] = bufftx[2] = bufftx[3] = 0;
	
	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);
	if (io_res < 0){
#ifdef DEBUG_SPI_SET_PARAMS
		printf(" Error: %d", io_res ); 
		perror ("\n SPI set params write op fail\n");
#endif	
		return -1;	
	}else{
#ifdef DEBUG_SPI_SET_PARAMS
		printf( "\n SPI set params wrote %d bytes\n", io_res );
#endif
	}

	if (debug_sw){
		print_row_buffer (bufftx, MCP2210_HID_REPORT_LEN, 10);
	}

	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);		

	
	if (io_res < 0){
#ifdef DEBUG_SPI_SET_PARAMS
		printf(" Error: %d", io_res ); 
		perror ("\n SPI set params read op fail\n");
#endif	
		return -2;	
	}else{
#ifdef DEBUG_SPI_SET_PARAMS
		printf( "\n SPI set params read %d bytes\n", io_res );
#endif
	}


	if (debug_sw){
		print_row_buffer (buffrx, MCP2210_HID_REPORT_LEN, 10);
	}	

	
	if ( buffrx[1] != DEV_NOERR ){
		printf("\nSPI set params CMD error\n");
		return -3;
	}	

		
	return 0;
}


/**
* @brief set chip device current settings 
*
* @param fd
* @param p_st_settings
*
* @return 
*/
int set_dev_curr_settings (int fd, st_dev_settings *p_st_settings, int debug_sw )
{
	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
	int io_res = 0;
	int i = 0;


	// Update settings.
	for(i = 0; i < DEV_NGPIOS; i++)
    	{
        	bufftx[4 + i] = p_st_settings->pin_opt[i];
		
    	}

	
	bufftx[13] = (uint8_t)(p_st_settings->gpio_out_defval & 0xFF);
	bufftx[14] = (uint8_t)((p_st_settings->gpio_out_defval & 0xFF00) >> 8);
	bufftx[15] = (uint8_t)(p_st_settings->gpio_direction & 0xFF);
	bufftx[16] = (uint8_t)((p_st_settings->gpio_direction & 0xFF00) >> 8);
	bufftx[17] = p_st_settings->spi_flags;
	
	// Send command to write settings
	bufftx[0] = CMD_WRITESETTINGS;
	bufftx[1] = bufftx[2] = bufftx[3] = 0; // fill rest of cmd with zero's??

	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_WRT_SETTINGS
		printf(" Error: %d", io_res ); 
		perror ("\n DEV set_settings write op fail\n");
#endif	
		return -1;	
	}else{
#ifdef DEBUG_WRT_SETTINGS
		printf( "\nDEV set_settings wrote %d bytes\n", io_res );
#endif
	}



	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);
		
	if (io_res < 0){
#ifdef DEBUG_WRT_SETTINGS
		printf(" Error: %d", io_res ); 
		perror ("\n DEV set_settings read op fail\n");
#endif	
		return -2;	
	}else{
#ifdef DEBUG_WRT_SETTINGS
		printf( "\nDEV set_settings read %d bytes\n", io_res );
#endif
	}

	if (debug_sw){
		print_row_buffer (bufftx, MCP2210_HID_REPORT_LEN, 10);
	}

	if ( buffrx[1] != DEV_NOERR ){
		printf("\nDEV set_settings CMD error\n");
		return -3;
	}	

	return 0;
}

/**
* @brief get chip device current settings 
*
* @param fd
* @param p_st_settings
*
* @return 
*/
int get_dev_curr_settings(int fd, st_dev_settings *p_st_settings, int debug_sw )
{
	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
	int io_res = 0;
	uint16_t *ptmp;


	// send CMD for read SPI DEV settings
	bufftx[0] = CMD_READSETTINGS;
	
	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);
	if (io_res < 0){
#ifdef DEBUG_GET_SETTINGS
		printf(" Error: %d", io_res ); 
		perror ("\n DEV get_settings write op fail\n");
#endif	
		return -1;	
	}else{
#ifdef DEBUG_GET_SETTINGS
		printf( "\nDEV get_settings wrote %d bytes\n", io_res );
#endif
	}

	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);
		
	if (io_res < 0){
#ifdef DEBUG_GET_SETTINGS
		printf(" Error: %d", io_res ); 
		perror ("\n DEV get_settings read op fail\n");
#endif	
		return -2;	
	}else{
#ifdef DEBUG_GET_SETTINGS
		printf( "\nDEV get_settings read %d bytes\n", io_res );
#endif
	}

	if (debug_sw ){
		print_row_buffer(buffrx, MCP2210_HID_REPORT_LEN, 10);
	}
	
	if ( buffrx[1] != DEV_NOERR  ){
		
		printf("\nDEV get_settings CMD error\n");
		return -3;
	}

	// Copy chip device info in little endian format
	memcpy((void * ) &p_st_settings->pin_opt, &buffrx[4], DEV_NGPIOS);
	ptmp				= (uint16_t *) &buffrx[4 + DEV_NGPIOS + 0]; // offset for default output values????
	p_st_settings->gpio_out_defval 	= le16toh(*ptmp);
	ptmp 				= (uint16_t *) &buffrx[4 + DEV_NGPIOS + 2]; // offset for direction GPIO
	p_st_settings->gpio_direction	= le16toh(*ptmp);
	p_st_settings->spi_flags 	= buffrx[4 + DEV_NGPIOS + 4]; 		// offset for SPI device flags		
	p_st_settings->nvram_flags	= buffrx[4 + DEV_NGPIOS + 5];		// offset for NVRAM flags of XMIT ops????


#ifdef DEBUG_GET_SETTINGS
	
if (debug_sw ){

	printf ( "\n\nCMD GET current Settings Result\n" );
	printf ( "\n-->GPIO Options:\n");
	print_row_buffer (p_st_settings->pin_opt, DEV_NGPIOS, DEV_NGPIOS);
	printf ( "\n-->GPIO Output Default Value: 0x%04x \n", p_st_settings->gpio_out_defval);	
	printf ( "\n-->GPIO I_O Direction: 0x%04x \n", p_st_settings->gpio_direction & 0x01FF);	
	printf ( "\n-->SPI Flags: 0x%02x \n", p_st_settings->spi_flags);	
	printf ( "\n-->NVRAM Flags: 0x%02x \n", p_st_settings->nvram_flags);	
}
#endif
	
	
	

	return 0;
}


/**
* @brief Cancels current SPI transmission to release from errors avoiding power cycle
*
* @param fd ( File Descriptor)
*
* @return 
*/
int cancel_curr_spi_xmit(int fd, uint8_t *spibus_release_status, uint8_t * spibus_curr_owner, int debug_sw )
{

	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
	int io_res = 0;

	// send CMD for cancel  
	bufftx[0] = CMD_CANCEL_SPI_XMIT;



	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_CANCEL_CURR_SPI_XMIT
		printf(" Error: %d", io_res ); 
		perror ("\nCANCEL curr_spi_xmit write op fail\n");
#endif	
		return -1;	
	}else{
#ifdef DEBUG_CANCEL_CURR_SPI_XMIT
		printf( "\nCANCEL curr_spi_xmit %d bytes\n", io_res );
#endif

	}

	
	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_CANCEL_CURR_SPI_XMIT
		printf(" Error: %d", io_res ); 
		perror ("\nCANCEL curr_spi_xmit read op fail\n");
#endif	
		return -2;	
	}else{
#ifdef DEBUG_CANCEL_CURR_SPI_XMIT
		printf( "\nCANCEL curr_spi_xmit read %d bytes\n", io_res );
#endif
	}
	
	if (debug_sw ){
		print_row_buffer(buffrx, MCP2210_HID_REPORT_LEN, 10);
	}
		
	if ( buffrx[1] != DEV_NOERR  ){
	
				 
		printf("\nDEV get_settings CMD error\n");
		return -3;
	}else{
		// get SPI bus status flags
		*spibus_release_status 	= (uint8_t) buffrx[2];
		*spibus_curr_owner 	= (uint8_t) buffrx[3];


	}

	return 0;
}

/**
* @brief Reads internal EEPROM 
*
* @param fd
* @param addr
* @param rdata
*
* @return 
*/
int read_eeprom( int fd, int addr, unsigned char *rdata )
{

	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
	int io_res = 0; 	

	bufftx[0] = CMD_INT_READEEPROM;
	bufftx[1] = (uint8_t)addr;
	
	//Write EEprom contents
    	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_INT_EEP	
		printf(" Error: %d", io_res ); 
		perror ("\n EEprom op read fail\n")
#endif	
		return -1;	
	}else{
#ifdef DEBUG_INT_EEP
		printf( "\nEEprom Read %d bytes\n", io_res );
#endif
	}
	
	//Read EEprom contents
	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_INT_EEP
		printf("\n Error: %d\n", io_res ); 
		perror ("\n EEprom op write fail\n")
#endif	
		return -1;	
	}else{
#ifdef DEBUG_INT_EEP
		printf( "\nEEprom Read %d bytes\n", io_res );
#endif
	}
	
  	


	 *rdata = buffrx[3];

	return 0;
}



/**
* @brief Assign GPIO direction properly in NVRAM
*
* @param fd
* @param gpio_dir
* @param gpio_mask
*
* @return error_code
*/
int gpio_direction(int fd, int gpio_dir, int gpio_mask, int debug_sw )
{
	st_dev_settings st_dev_dir_setup;
	int i = 0;
	int io_res = 0;
	uint16_t ui_tmp_var = 0;
	uint16_t gpio_dir_r = 0;

	// fetch current device settings
	io_res = get_dev_curr_settings(fd, &st_dev_dir_setup, debug_sw );	
		
	if (io_res != 0){

		return -1;
	}
	
	// write GPIO desired setup 
	for (i = 0; i< DEV_NGPIOS; i++ ){
		ui_tmp_var  = 1 << i;
		
		// assert GPIO function 
		if (gpio_mask & (1<<i))	{
			st_dev_dir_setup.pin_opt[i] &= GPN_PIN_GPIO;
			
			// assign mask in loop to current values
			st_dev_dir_setup.gpio_direction &= ((uint16_t) (~( ui_tmp_var ))); // clear direction bit
			st_dev_dir_setup.gpio_direction |= ((uint16_t) ( ui_tmp_var & gpio_dir )); // assign direction value	  
#ifdef DEBUG_GIO_DIRECTION
		if (debug_sw){
			printf( "\n Pin Dir Setup [ %d ] =  %04x\n" ,  i , st_dev_dir_setup.gpio_direction  );
		}
#endif

		}

	}

	
	//write GPIO settings to device
	io_res = set_dev_curr_settings(fd, &st_dev_dir_setup, debug_sw);	
		
	if (io_res != 0 ){

		return -2;
	}
	
	// double check data written
	io_res = get_dev_curr_settings(fd, &st_dev_dir_setup, debug_sw);	

		
	if (io_res != 0){

		return -3;
	}
	//write settings to volatile memory
	io_res = gpio_setdir(fd, (uint16_t) gpio_dir, debug_sw);
	if (io_res != 0){

		return -4;
	}

	
	//2019-08-05
	// Check if gpio_setdir are really set on ram as in the nvram

	io_res = gpio_getdir(fd, &gpio_dir_r, debug_sw);

	if(io_res != 0){

		return -5;
	}
	
#ifdef DEBUG_GIO_DIRECTION
	printf("\nGet GPIO DIR on RAM : %04x\n", gpio_dir_r);
#endif	
	
	ui_tmp_var =  ( (uint16_t) (gpio_mask  &  gpio_dir));
	if ( ui_tmp_var == gpio_dir ){
		
#ifdef DEBUG_GIO_DIRECTION
		printf("\n---->Set GPIO DIR OK\n");
#endif	

	
		
	}else{
#ifdef DEBUG_GIO_DIRECTION
		printf("\n--->!!!!!Set GPIO DIR KO!!!!!!\n");
#endif	

		return -6;
	}



	return 0;
}


/**
* @brief Set MCP2210 GPIO's direction function on RAM

*
* @param fd
* @param gpio_dir
*
* @return 
*/
int gpio_setdir(int fd, uint16_t gpio_dir, int debug_sw)
{
	

	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
	int io_res = 0;	

 	bufftx[0] = CMD_SETGPIODIR;
    	bufftx[4] = (uint8_t)(gpio_dir & 0xFF);
    	bufftx[5] = (uint8_t)((gpio_dir & 0xFF00) >> 8);
	
		
	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_GPIOSETDIR	
		printf(" Error: %d", io_res ); 
		perror ("\n GPIO SetDir op write fail\n");
#endif	
		return -1;	
	}else{
#ifdef DEBUG_GPIOSETDIR
		printf( "\nGPIO SetDir Wrote %d bytes\n", io_res );
#endif
	}	



	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_GPIOSETDIR	
		printf(" Error: %d", io_res ); 
		perror ("\n GPIO SetDir op read fail\n");
#endif	
		return -2;	
	}else{
#ifdef DEBUG_GPIOSETDIR
		printf( "\n GPIO SetDir read %d bytes\n", io_res );
#endif
	}

	if (debug_sw ){
		print_row_buffer(buffrx, MCP2210_HID_REPORT_LEN, 10);
	}
	
	if ( buffrx[1] != DEV_NOERR ){

		if( buffrx[1] == DEV_BLOCKEDACCESS  ){
			printf( "\nSet DIR read blockedAccess Error\n");
			
			return -4;	
		}

			printf( "\nSet DIR read Error\n");
			
		return -3;
	}

	return 0;
}

/**
* @brief Get MCP2210 GPIO's direction function on RAM
*
* @param fd
* @param gpio_dir
*
* @return 
*/
int gpio_getdir(int fd, uint16_t * gpio_dir, int debug_sw )
{
	
	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
	uint16_t ui_tmp_var = 0;
	int io_res = 0;	

		
 	bufftx[0] = CMD_GETGPIODIR;

	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);
	
	if (io_res < 0){
#ifdef DEBUG_GPIOGETDIR	
		printf(" Error: %d", io_res ); 
		perror ("\n GPIO GetDir op write fail\n");
#endif	
		return -1;	
	}else{
#ifdef DEBUG_GPIOGETDIR
		printf( "\nGPIO GetDir Wrote %d bytes\n", io_res );
#endif
	}	

			
	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);
		
	if (io_res < 0){
#ifdef DEBUG_GPIOGETDIR	
		printf(" Error: %d", io_res ); 
		perror ("\n GPIO GetDir op read fail\n");
#endif	
		return -2;	
	}else{
#ifdef DEBUG_GPIOGETDIR
		printf( "\n GPIO GetDir read %d bytes\n", io_res );
#endif
	}

	if (debug_sw){
		print_row_buffer(buffrx, MCP2210_HID_REPORT_LEN, 10);
	}

	if (buffrx [1] != DEV_NOERR){

		if ( buffrx [1] == DEV_BLOCKEDACCESS ){
			
#ifdef DEBUG_GPIOGETDIR
			printf( "\n GPIO GetDir cmd blocked Access error\n");
#endif	
		} 



#ifdef DEBUG_GPIOGETDIR
		printf( "\n GPIO GetDir cmd error\n");
#endif
		return -3;
	}

	ui_tmp_var = ((uint16_t) (buffrx[4]  & 0x00FF ));
	ui_tmp_var |= ((uint16_t)  (  (buffrx[5] << 8) & 0xFF00 )  );
	*gpio_dir = ui_tmp_var;		


	return 0;
}



int gpio_out_value(int fd , int gpio_val, int gpio_mask, int debug_sw )
{
	st_dev_settings st_gpn_out_settings;	
	int i = 0;
	int io_res = 0;
	uint16_t ui_tmp_val, ui_tmp_dir = 0;
		

	// get current settings from chip device
	io_res = get_dev_curr_settings(fd, &st_gpn_out_settings, debug_sw);
	
	if (io_res != 0 ){
		
		return -1;
	}	
	 
	// set/clear the desired GPIOS 
	for ( i = 0; i < DEV_NGPIOS; i++){
		ui_tmp_val = 1 << i;
		ui_tmp_dir = 1 << i;
			
		if (gpio_mask & (1<<i)){
			st_gpn_out_settings.pin_opt[i] = GPN_PIN_GPIO;
			st_gpn_out_settings.gpio_direction &= ((uint16_t) ( ~ (ui_tmp_dir) )); // Force clear to set it as output. 
			st_gpn_out_settings.gpio_out_defval &= ((uint16_t) ( ~ (ui_tmp_val) ));  // Clear desired bit
			st_gpn_out_settings.gpio_out_defval |= ((uint16_t) (ui_tmp_val & gpio_val) ); // Write bit value
		}
	}	


	// set chip device current settings 
	io_res = set_dev_curr_settings(fd, &st_gpn_out_settings, debug_sw);
	
	if (io_res != 0 ){
		
		return -2;
	}		


#ifdef DEBUG_GPIO_OUT_VAL	
	printf("\n---> GPIO  OUT NVRAM SETTINGS <---\n");
#endif
	// get back current settings from chip device for checking good writing
	io_res = get_dev_curr_settings(fd, &st_gpn_out_settings, debug_sw);

	if (io_res != 0 ){
		
		return -3;
	}		



	// write gpio settings on RAM

	io_res = gpio_set_pin_val(fd, (uint16_t) gpio_val, debug_sw);

	if (io_res != 0 ){
		
		return -4;
	}		


	return 0;
}


/**
* @brief Read GPIO inputs from NVRAM and RAM 
*
* @param fd
* @param p_gpioin_val
* @param gpio_mask
*
* @return 
*/
int gpio_in_value ( int fd, int *p_gpioin_val, int gpio_mask, int debug_sw )
{
	st_dev_settings st_gpio_in_settings;
	int i = 0;
	int io_res = 0;
	uint16_t ui_tmp_val = 0;
	uint16_t ui_tmp_dir = 0;	

	// get current device settings for gpio inputs status
	io_res = get_dev_curr_settings(fd, &st_gpio_in_settings, debug_sw);

	if (io_res != 0){

		return -1;
	}

	// set GPIO input direction on NVRAM
	for(i = 0; i < DEV_NGPIOS; i++){
		
		///ui_tmp_val = 1 << i;	// needed???? Seriously.....
		ui_tmp_dir = 1 << i;
	
		if (gpio_mask & ( 1<< i)){
			st_gpio_in_settings.pin_opt[i] = GPN_PIN_GPIO;
			st_gpio_in_settings.gpio_direction |= (ui_tmp_dir);

		}
	}

	
	// set current device settings for desired gpio inputs 
	io_res = set_dev_curr_settings(fd, &st_gpio_in_settings, debug_sw);

	if (io_res != 0){

		return -2;
	}

	// read back  current device settings for double check
	io_res = get_dev_curr_settings(fd, &st_gpio_in_settings, debug_sw);

	if (io_res != 0){

		return -3;
	}
#ifdef DEBUG_GPIO_IN_VAL	
	printf("\n---> GPIO IN NVRAM SETTINGS <---\n");
#endif

	// read GPIO from RAM
	io_res = gpio_get_pin_val(fd, &ui_tmp_val, debug_sw);
	
	if (io_res != 0){

		return -4;
	}


	*p_gpioin_val = (int) (ui_tmp_val & gpio_mask );


	return 0;
}



/**
* @brief Set pin current value on RAM
*
* @param fd
* @param gpio_val
*
* @return 
*/
int gpio_set_pin_val(int fd, uint16_t gpio_val, int debug_sw)
{
	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
			
	int io_res = 0;
	
	bufftx[0] = CMD_SETGPIO;
	bufftx[4] = (uint8_t) ( gpio_val & 0x00FF ) ;
	bufftx[5] = (uint8_t) (( gpio_val & 0xFF00) >> 8 ) ;
		
	
	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_GPIOSETVAL	
		printf(" Error: %d", io_res ); 
		perror ("\n GPIO SetVal op write fail\n");
#endif	
		return -1;	
	}else{
#ifdef DEBUG_GPIOSETVAL
		printf( "\nGPIO SetVal Wrote %d bytes\n", io_res );
#endif
	}	

	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);

	if (io_res < 0){
#ifdef DEBUG_GPIOSETVAL	
		printf(" Error: %d", io_res ); 
		perror ("\n GPIO SetVal op read fail\n");
#endif	
		return -2;	
	}else{
#ifdef DEBUG_GPIOSETVAL
		printf( "\nGPIO SetVal Read %d bytes\n", io_res );
#endif
	}

	if (debug_sw){
		print_row_buffer(buffrx, MCP2210_HID_REPORT_LEN, 10 );
	}	

	if ( buffrx[1] != DEV_NOERR ){
		
		
		if ( buffrx[1] == DEV_BLOCKEDACCESS ){
#ifdef DEBUG_GPIOSETVAL
			printf( "\nGPIO SetVal blocked access error\n");
#endif
			return -4;
		}
#ifdef DEBUG_GPIOSETVAL
		printf( "\nGPIO SetVal cmd error\n");
#endif
	
		return -3;
	}
	
	return 0;
}




/**
* @brief GET pin current value on RAM
*
* @param fd
* @param gpio_val
*
* @return 
*/
int gpio_get_pin_val(int fd, uint16_t *gpio_val, int debug_sw )
{
	unsigned char bufftx[MCP2210_HID_REPORT_LEN];
	unsigned char buffrx[MCP2210_HID_REPORT_LEN];
			
	int io_res = 0;
	uint16_t ui_tmp_var = 0;
	
	bufftx[0] = CMD_GETGPIO;

	io_res = write(fd, bufftx, MCP2210_HID_REPORT_LEN);
		
	if (io_res < 0){
#ifdef DEBUG_GPIOGETVAL	
		printf(" Error: %d", io_res ); 
		perror ("\n GPIO GetVal op write fail\n");
#endif	
		return -1;	
	}else{
#ifdef DEBUG_GPIOGETVAL
		printf( "\nGPIO GetVal Wrote %d bytes\n", io_res );
#endif

	}
	io_res = read(fd, buffrx, MCP2210_HID_REPORT_LEN);
	
	if (io_res < 0){
#ifdef DEBUG_GPIOGETVAL	
		printf(" Error: %d", io_res ); 
		perror ("\n GPIO GetVal op read fail\n");
#endif	
		return -2;	
	}else{
#ifdef DEBUG_GPIOGETVAL
		printf( "\nGPIO GetVal Read %d bytes\n", io_res );
#endif
	}

	if (debug_sw){
		print_row_buffer(buffrx, MCP2210_HID_REPORT_LEN, 10 );
	}
	
	if ( buffrx[1] != DEV_NOERR ){
		
		
		if ( buffrx[1] == DEV_BLOCKEDACCESS ){
#ifdef DEBUG_GPIOGETVAL
			printf( "\nGPIO GetVal blocked access error\n");
#endif
			return -4;
		}
#ifdef DEBUG_GPIOGETVAL
		printf( "\nGPIO GetVal cmd error\n");
#endif
	
		return -3;
	}

	ui_tmp_var = ((uint16_t) (buffrx[4]) & 0x00FF);
	ui_tmp_var |= ((uint16_t) ((buffrx[5] << 8 ) & 0xFF00) );
	*gpio_val = ui_tmp_var;	


	return 0;
}





/**
* @brief Print Hex buffer
*
* @param buff
* @param len
* @param row_len
*/
void print_row_buffer(unsigned char *buff, int len, int row_len)
{
    int i = 0;
    int irow_cnt = 0;

    while(i < len)
    {
        if ((i%row_len) == 0)
        {/* new row needed */
            printf("\n%04d: ", i);
        }
        for(irow_cnt = 0; ((irow_cnt < row_len) && (i < len));)
        {
            printf("  %02X", buff[i]);
            irow_cnt++;
            i++;
        }
    }
}


#ifdef USE_GETOPTS

void usage(void){

	printf (" Usage: ");
	printf (" --> -Internal EEPROM  (Sanity Check): ./program -D <dev> \n");
	printf (" --> -External SPI EEPROM : ./program -D <dev> -S\n");
	printf (" --> Input: ./program -D <dev> -P  <gpio_num> \n");
	printf (" --> -Output : ./program -D <dev> -P <gpio_num> -V [1/0]\n");
	printf (" --> Debug / verbose ./program -D <dev> [opts] -d\n");
	
}


#endif

