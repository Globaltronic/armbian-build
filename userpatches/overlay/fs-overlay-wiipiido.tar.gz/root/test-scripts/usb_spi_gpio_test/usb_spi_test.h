#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <asm/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/hiddev.h>
#include <linux/input.h>
#include <time.h>
#include <ctype.h>
#include <getopt.h>
#include <stdint.h>
#include <endian.h>



// Test code activation macros
//#define TEST_USB_SPI_SANITY
#define TEST_SPI_EEPROM_WRITE
#define TEST_SPI_EEPROM_READ
#define TEST_SPI_GPIOS
//#define TEST_SET_GIO_RAM
//#define TEST_GPIO_OUT_VALUE
#define TEST_GPIO_IN_VALUE

// debug macros
//#define DEBUG_INT_EEP // turn on debug for internal EEPROM data
#define DEBUG_XMIT_SPI_DATA
#define DEBUG_GET_STATUS
#define DEBUG_GET_SETTINGS
#define DEBUG_WRT_SETTINGS
#define DEBUG_SPI_SET_PARAMS
#define DEBUG_SPI_GET_PARAMS
#define DEBUG_XMIT_SPI_DATA
#define DEBUG_CANCEL_CURR_SPI_XMIT
#define DEBUG_GPIOSETDIR
#define DEBUG_GPIOGETDIR
#define DEBUG_GIO_DIRECTION
#define DEBUG_GPIOSETVAL
#define DEBUG_GPIO_OUT_VAL
#define DEBUG_GPIO_IN_VAL


// MCP2210 macros
#define MCP2210_HID_REPORT_LEN		64 
#define MCP2210_MAX_SPI_DATA_LEN	60
#define MCP2210_XMIT_TRYOUTS		200


#define DEV_NGPIOS			9

// usb spi macros 
#define CMD_GETSTATUS			0x10
#define CMD_CANCEL_SPI_XMIT		0x11
#define CMD_READSETTINGS		0x20
#define CMD_WRITESETTINGS		0x21
#define CMD_SETGPIO			0x30
#define CMD_GETGPIO			0x31
#define CMD_SETGPIODIR			0x32
#define CMD_GETGPIODIR			0x33
#define CMD_SETSPITRANSACTION		0x40
#define CMD_SETSPITRANSACTION		0x40
#define CMD_GETSPITRANSACTION		0x41
#define CMD_XMITSPIDATA			0x42
#define CMD_INT_READEEPROM		0x50

// chip device macros

#define DEV_NOERR			0x00
#define DEV_SPI_XMIT_RXDATAEND		0x10
#define DEV_SPI_XMIT_NORXDATA		0x20
#define DEV_SPI_XMIT_RXDATA		0x30
#define DEV_SPI_XMITONGOING		0xF8
#define DEV_SPI_BUSHIZ			0xF7
#define DEV_BLOCKEDACCESS		0xFB


// pin designation
#define GPN_PIN_GPIO                                   0x00	// GPIO 
#define GPN_PIN_ALTFUNC_1                              0x01	// chip select 
#define GPN_PIN_ALTFUNC_2                              0x02 	// interrupts, LED's


// optional macros 
#define USE_GETOPTS


typedef struct st_devstatus_s
{
	uint8_t spi_state;
	uint8_t dat_usb_xmited;
	uint8_t dat_usb_to_xmit;
	uint8_t dat_xmited;
	uint8_t usb_cmd_wait;
}st_devstatus;

typedef struct st_dev_settings_s
{
	uint8_t 	pin_opt[DEV_NGPIOS];
	uint16_t 	gpio_out_defval;
	uint16_t 	gpio_direction;
	uint8_t		spi_flags;
	uint8_t 	nvram_flags;

}st_dev_settings;


typedef struct st_spi_xmit_settings_s
{
	uint32_t 	baudrate;
	uint16_t 	idle_cs_sel;
	uint16_t 	active_cs_sel;
	uint16_t 	cs2data_cs_dly;
	uint16_t 	data2cs_dly;
	uint16_t 	data2data_dly;
	uint16_t 	data2xmit;
	uint8_t 	spi_mode_flags;	
}st_spi_xmit_settings;



// prototypes
int spi_data_xmit(int fd, unsigned char *tx_data,
                                        unsigned char *rx_data, int xmit_length,
                                        int spi_mode, int spi_speed,
                                        int act_cs_val, int idle_cs_val, int gpcsmask,
                                        int cs2datadly, int data2datadly, int data2csdly, int debug_sw );


int xmit_spi_data(int fd, unsigned char *tx_data,
                    unsigned char *rx_data, uint8_t *p_data_len_tx,
                    uint8_t *p_data_len_rx, uint8_t *p_res_code, int debug_sw );


int get_dev_status(int fd, st_devstatus *ptsdevstatus, int debug_sw );
int get_spi_xmit_params(int fd, st_spi_xmit_settings *p_st_xmit_setup, int debug_sw );
int set_spi_xmit_params(int fd, st_spi_xmit_settings *p_st_xmit_setup, int debug_sw );
int set_dev_curr_settings (int fd, st_dev_settings *p_st_settings, int debug_sw );
int get_dev_curr_settings(int fd, st_dev_settings *p_st_settings, int debug_sw );
int gpio_direction(int fd, int gpio_dir, int gpio_mask, int debug_sw );
int cancel_curr_spi_xmit(int fd, uint8_t *spibus_release_status, uint8_t * spibus_curr_owner , int debug_sw );
int gpio_getdir(int fd, uint16_t * gpio_dir, int debug_sw );
int gpio_out_value(int fd , int gpio_val, int gpio_mask, int debug_sw );
int gpio_in_value ( int fd, int *p_gpioin_val, int gpio_mask, int debug_sw );
int gpio_setdir(int fd, uint16_t gpio_dir, int debug_sw );
int gpio_set_pin_val(int fd, uint16_t gpio_val, int debug_sw );
int gpio_get_pin_val(int fd, uint16_t *gpio_val, int debug_sw );
int read_eeprom( int fd, int addr, unsigned char *rdata);
void print_row_buffer(unsigned char *buff, int len, int row_len);
void usage(void);


