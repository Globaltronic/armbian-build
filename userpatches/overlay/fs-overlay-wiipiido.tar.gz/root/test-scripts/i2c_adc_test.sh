#!/bin/bash

#2019-07-18: Read values in loop from the I2C ADC MCP3204


my_name=`basename $0`
echo "0.01" > /tmp/ver_${my_name}


while true; do grep . /sys/devices/platform/soc/1c2ac00.i2c/i2c-0/0-006c/iio:device0/in_voltage[0,1,2,3]_raw ; sleep 1; done


