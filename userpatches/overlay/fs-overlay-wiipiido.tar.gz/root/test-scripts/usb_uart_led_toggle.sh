#!/bin/bash

# 2020-01-20
# test script for toggle LED's from CP210x UART Bridge
# using the custom cp210x_gpio


file_name=$(basename $0)
sudo /bin/bash -c "echo \"0.02\" > /tmp/ver_${file_name}"

usage(){

	echo "Toggle LED's from CP210x UART Bridge"
	echo " $(basename $0) [on|off] "
	echo "choose 'on' or 'off' value"
}


# check if driver is installed properley
#silabs_driver_st=`sudo /bin/bash -c "/sbin/modinfo cp210x | grep 'Silicon Labs'"`
silabs_driver_st=`sudo /bin/bash -c "/sbin/modinfo cp210x_gpio | grep 'Silicon Labs'"`

if [ "$silabs_driver_st" == "" ]; then
	echo "Driver Not installed"
	echo "Please install Silicon Labs driver"
	exit 1
fi


# test if there is gpio linked to port


silabs_gpio_dirs=`sudo /bin/bash -c "ls /sys/class/gpio/gpiochip???/device/ttyUSB?/  | grep gpiochip"`


if [ "$silabs_gpio_dirs" == ""  ]; then
	echo "Missing custom Silabs driver"
	echo "Recompile custom driver"
	exit 2
fi

if [ "$1" == "on" ]; then
	let gpio_value=0
elif [ "$1" == "off" ]; then
	let gpio_value=1
else
	usage
	exit 6
fi	

echo "Silabs Dirs : $silabs_gpio_dirs"


for i in $silabs_gpio_dirs; do

	#silabs_gpiochip_dir='echo $i '
	echo " Line Raw $i"
		
	# get gpiochip path from sysfs	
	silabs_gpiochip_dir=`echo $i | sed -nr "s/\r//;s/(.*)(\/device\/ttyUSB[0-9]\/)(.*)/\1/p"`
	echo " GPIO Path $silabs_gpiochip_dir"

	# get num of GPIO's available per gpio_dir

	silabs_ngpio=`eval cat $silabs_gpiochip_dir/ngpio`	
	echo " nGPIO Per Serial: $silabs_ngpio"

	if [ "$silabs_ngpio" == "0"  ]; then
		echo "driver GPIO count error"
		exit 3
	elif [  "$silabs_ngpio" == "" ]; then
		echo "Driver or device error"
		exit 4
	else
		silabs_gpio_index=`echo $silabs_gpiochip_dir | sed -nr "s/(.*)gpiochip([0-9]{3})$/\2/p"`
		echo "GPIO Index: $silabs_gpio_index"
		

		if [  "$silabs_gpio_index" == "" ]; then
			echo "Invalid GPIOchip Index"
			exit 5
		fi 

		let j=0



		# cycle all GPIO's at given index
		while [ $j -lt $silabs_ngpio ]; do
	
			let xgpio_num=$(( j + silabs_gpio_index ))	
				
				# check if gpio is already exported to avoid glitches, if not export as outputs 
				is_xpio_xported=`ls -l /sys/class/gpio/gpio$xgpio_num/direction`
				if [ "$is_xpio_xported" == "" ]; then
					sudo /bin/bash -c "echo $xgpio_num  > /sys/class/gpio/export"
					sudo /bin/bash -c "echo out > /sys/class/gpio/gpio$xgpio_num/direction" 	
				fi
				
			sudo /bin/bash -c "echo $gpio_value > /sys/class/gpio/gpio$xgpio_num/value" 	
			let j=$(( j +1 ))
			#sleep 1
		done 
	fi
		

done
