#!/bin/bash


#  2019-06-17
#  Script to give info about CPU thermal- open SSH session for 

my_name=`basename $0`
echo "0.01" > /tmp/ver_${my_name}



while true; do grep . /sys/devices/system/cpu/cpu?/cpufreq/cpuinfo_cur_freq ;echo;grep . /sys/devices/virtual/thermal/thermal_zone[0,1,2]/temp  ; echo; sleep 1; done
