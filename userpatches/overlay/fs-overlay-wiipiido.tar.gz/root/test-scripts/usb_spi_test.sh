#!/bin/bash

# 2019-07-18 : Test USB SPI brigde + GPIO with EEPROM SPI 25LC040
# 2019-07-30 : Change eeprom demo testing
# 2019-08-06 : Using custom program driver
# 2019-08-08 : Changing arguments of main program using getopts

file_name=$(basename $0)
echo "0.04" > /tmp/ver_${file_name}

# Obsolete - driver already supports it
if [ ! -f $HOME/MCP2210_linux_library/runme.sh ]; then
	echo "MCP2210 Interface lib not found"
	exit 1
fi

if [ ! -f $HOME/usb_spi_gpio_test/usb_spi_test ]; then
	echo "MCP2210 Interface lib not compiled. Run Makefile"
	exit 2
fi

# generate HIDRAW dev


hidraw_msg=`/bin/bash -c "$HOME/MCP2210_linux_library/runme.sh"`

hidraw_dev=`echo ${hidraw_msg} | sed -nr "s/\r//;s/.*\"(\S+)\"/\1/p"`


if [  -c ${hidraw_dev} ]; then

home_user=$HOME

# Read / Write Eeprom and read back to get result.
sudo /bin/bash -c "$home_user/usb_spi_gpio_test/usb_spi_test -D $hidraw_dev -S > /dev/null 2>&1"
eeprom_report=`sudo /bin/bash -c "$home_user/usb_spi_gpio_test/usb_spi_test -D $hidraw_dev -S"`

else
	echo "No HIDRAW found. Execute runme.sh"
	exit 3
fi


# report test ok / ko

eeprom_data=`echo ${eeprom_report} | sed -nr "s/\r//;s/.*0000:(\s*([A-F0-9]{2})\s*([A-F0-9]{2})\s*([A-F0-9]{2})).*/\2\3\4/gp"`

echo "EEProm Data : ${eeprom_data}"

if [ "$eeprom_data" != "000000" ]; then
	echo -ne "USBSPI;${eeprom_data};OK"
else
	echo -ne "USBSPI;KO"
fi

