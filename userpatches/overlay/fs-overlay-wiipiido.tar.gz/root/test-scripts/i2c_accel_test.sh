#!/bin/bash


#2019-07-18: Read values in loop from the I2C accell LIS3E 
# Address can be either 0x29 or 0x28

my_name=`basename $0`
echo "0.02" > /tmp/ver_${my_name}


if [ -f /sys/devices/platform/soc/1c2ac00.i2c/i2c-0/0-0029/iio:device1/in_accel_x_raw ]; then
	while true; do grep . /sys/devices/platform/soc/1c2ac00.i2c/i2c-0/0-0029/iio:device1/in_accel_[x,y,z]_raw; done
elif [ -f /sys/devices/platform/soc/1c2ac00.i2c/i2c-0/0-0028/iio:device1/in_accel_x_raw ]; then
	while true; do grep . /sys/devices/platform/soc/1c2ac00.i2c/i2c-0/0-0028/iio:device1/in_accel_[x,y,z]_raw; done
else
	echo "Error ST Accel Driver not loaded;KO"
fi
