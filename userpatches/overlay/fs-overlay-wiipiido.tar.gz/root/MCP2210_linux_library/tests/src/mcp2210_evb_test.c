/*
© [2018] Microchip Technology Inc. and its subsidiaries.

Subject to your compliance with these terms, you may use Microchip software and
any derivatives exclusively with Microchip products. It is your responsibility
to comply with third party license terms applicable to your use of third party
software (including open source software) that may accompany Microchip software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS,
IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES
OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.

IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF
THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS
SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY
TO MICROCHIP FOR THIS SOFTWARE.
*/
#include <mcp2210_api.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#define SPI_BUF_LEN							1024

void fill_pattern(uint8_t *pdata, int len);

int main(int argc, char **argv)
{
	int ictr, iRes, itmp;
	int fd;
	unsigned char txdata[SPI_BUF_LEN], rxdata[SPI_BUF_LEN];
	int xferlength;
	int spimode;
	int speed;
	int actcsval;
	int idlecsval;
	int gpcsmask;
	int cs2datadly;
	int data2datadly;
	int data2csdly;

	printf("\nMCP2210 Evaluation Board Tests");
	printf("\nParameters: %d\n", argc);
	for (ictr = 0; ictr < argc; ictr++)
	{
		printf("\nParameter(%d) -> %s", ictr, argv[ictr]);
	}

	if (argc > 1)
	{
		printf("\nTry to open:\"%s\"", argv[1]);
		fd = open_device(argv[1]);
		if (fd > 0)
		{
			printf("\nDevice successfully opened\n\n");

#ifdef TEST_SPI_OPS
			/* make an SPI transfer */
			spimode			= 0;
			speed			= 1000000;
			actcsval		= 0xFFEF;
			idlecsval		= 0xFFFF;
			gpcsmask		= 0x0010;
			cs2datadly		= 0;
			data2datadly	= 0;
			data2csdly		= 0;
			xferlength		= 4;

            txdata[0] = 0x40;
			txdata[1] = 0x05;
			txdata[2] = 0x00; /* enable the sequential addr incr */
            xferlength = 3;

            iRes = spi_data_xfer(fd, txdata, rxdata, xferlength,
                    spimode, speed, actcsval, idlecsval,
                    gpcsmask, cs2datadly, data2datadly,
                    data2csdly);
			printf("\nSPI Xfer() returned -> %d", iRes);

			txdata[0] = 0x40;
			txdata[1] = 0x0A;
			txdata[2] = 0xA5;
			txdata[3] = 0x00;
            xferlength = 4;

			iRes = spi_data_xfer(fd, txdata, rxdata, xferlength,
								spimode, speed, actcsval, idlecsval,
								gpcsmask, cs2datadly, data2datadly,
								data2csdly);
			printf("\nSPI Xfer() returned -> %d", iRes);

            txdata[0] = 0x40;
			txdata[1] = 0x0A;
			txdata[2] = 0x81;
			txdata[3] = 0x00;
            xferlength = 4;

            iRes = spi_data_xfer(fd, txdata, rxdata, xferlength,
                    spimode, speed, actcsval, idlecsval,
                    gpcsmask, cs2datadly, data2datadly,
                    data2csdly);
			printf("\nSPI Xfer() returned -> %d", iRes);

            txdata[0] = 0x40;
			txdata[1] = 0x05;
			txdata[2] = 0x20; /* disable the sequential addr incr */
            xferlength = 3;

            iRes = spi_data_xfer(fd, txdata, rxdata, xferlength,
                    spimode, speed, actcsval, idlecsval,
                    gpcsmask, cs2datadly, data2datadly,
                    data2csdly);
			printf("\nSPI Xfer() returned -> %d", iRes);

            txdata[0] = 0x40;
			txdata[1] = 0x0A;
            xferlength = 70;
            fill_pattern(&txdata[2], xferlength - 2);

            iRes = spi_data_xfer(fd, txdata, rxdata, xferlength,
                    spimode, speed, actcsval, idlecsval,
                    gpcsmask, cs2datadly, data2datadly,
                    data2csdly);
			printf("\nSPI Xfer() returned -> %d", iRes);

            txdata[0] = 0x40;
			txdata[1] = 0x0A;
            xferlength = 120;
            fill_pattern(&txdata[2], xferlength - 2);

            iRes = spi_data_xfer(fd, txdata, rxdata, xferlength,
                    spimode, speed, actcsval, idlecsval,
                    gpcsmask, cs2datadly, data2datadly,
                    data2csdly);
			printf("\nSPI Xfer() returned -> %d", iRes);

            txdata[0] = 0x40;
			txdata[1] = 0x0A;
            xferlength = 130;
            fill_pattern(&txdata[2], xferlength - 2);

            iRes = spi_data_xfer(fd, txdata, rxdata, xferlength,
                    spimode, speed, actcsval, idlecsval,
                    gpcsmask, cs2datadly, data2datadly,
                    data2csdly);
			printf("\nSPI Xfer() returned -> %d", iRes);

            /* READ EEPROM CONTENTS - 25LC020 (256 bytes capacity)*/
            printf("\n\n\nRead the EEPROM memory content from MCP2210 Evaluation Board\n");
            txdata[0] = 0x03; /*command to read the EEPROM*/
			txdata[1] = 0x00; /*address to start the read process*/
            xferlength = 258; /*we need to read 256bytes + 2 overhead*/

            actcsval		= 0xFFFE;
			idlecsval		= 0xFFFF;
			gpcsmask		= 0x0001;

            iRes = spi_data_xfer(fd, txdata, rxdata, xferlength,
                    spimode, speed, actcsval, idlecsval,
                    gpcsmask, cs2datadly, data2datadly,
                    data2csdly);
			printf("\nSPI Xfer() returned -> %d", iRes);
            print_report_buffer(&rxdata[2], 256, 8);
#endif

#if TEST_EEPROM_WRITE
                        /* WRITE MCP2210 EEPROM CONTENTS - (256 bytes capacity)*/
                        /* write the internal MCP2210 EEPROM */
                        printf("\n\n\nWrite the EEPROM memory content of MCP2210\n");
                        iRes = write_eeprom(fd, 0, 0xDE);
                        printf("\nEEPROM Write() returned -> %d", iRes);
                        iRes = write_eeprom(fd, 1, 0xAD);
                        printf("\nEEPROM Write() returned -> %d", iRes);
                        iRes = write_eeprom(fd, 2, 0xBE);
                        printf("\nEEPROM Write() returned -> %d", iRes);
                        iRes = write_eeprom(fd, 3, 0xEF);
                        printf("\nEEPROM Write() returned -> %d", iRes);
#endif

#ifdef TEST_EEPROM_READ
                        /* READ the entire MCP2210 EEPROM */
                        printf("\n\n\nRead the EEPROM memory content of MCP2210\n");
                        for(ictr = 0; ictr < MCP2210_EEPROM_LEN; ictr++)
                        {
                            iRes = read_eeprom(fd, ictr, &rxdata[ictr]);
                            if (iRes < 0)
                            {
                                printf("\n\nEEPROM Read() FAILED!!! addr: %d", ictr);
                                break;
                            }
                        }

                        if (iRes == ERR_NOERR)
                        {
                            print_report_buffer(&rxdata[0], MCP2210_EEPROM_LEN, 8);
                        }
#endif

#ifdef TEST_GPIO_OUT
                        printf("\n\n\nSet all MCP2210 GP pins as GPIO outputs\n");
                        /* setup GPIOs direction to outputs */
                        iRes = gpio_direction(fd, 0x0000, 0x01FF);
                        printf("\nGPIO SetDir() returned -> %d", iRes);

                        printf("\n\n\nSet all MCP2210 GPIO outputs with all zeroes, ones and again zeroes\n");
                        /* write the GP values - all zeroes */
                        iRes = gpio_write(fd, 0x0000, 0x01FF);
                        printf("\nGPIO Write() returned -> %d", iRes);
                        printf("\nPress a key to continue...");
                        getchar();
                        /* write the GP values - all ones */
                        iRes = gpio_write(fd, 0x01FF, 0x01FF);
                        printf("\nGPIO Write() returned -> %d", iRes);
                        printf("\nPress a key to continue...");
                        getchar();
                        /* write the GP values - all zeroes */
                        iRes = gpio_write(fd, 0x0000, 0x01FF);
                        printf("\nGPIO Write() returned -> %d", iRes);
                        printf("\nPress a key to continue...");
                        getchar();
#endif

#ifdef TEST_GPIO_IN
                        printf("\n\n\nSet all MCP2210 GP pins as GPIO inputs and read them\n");
                        /* setup GPIOs direction to inputs */
                        iRes = gpio_direction(fd, 0x01FF, 0x01FF);
                        printf("\nGPIO SetDir() returned -> %d", iRes);

                        printf("\nPress a key to continue...");
                        getchar();

                        /* read the GP values */
                        printf("\n\n\nRead all MCP2210 GPIO inputs\n");
                        iRes = gpio_read(fd, &itmp, 0x01FF);
                        printf("\nGPIO Read() returned -> %d", iRes);
                        printf("\nGPIO read value: 0x%04X", itmp);
#endif

			iRes = close_device(fd);
			printf("\n\n\nDevice closed -> %d", iRes);
		}
		else
		{
			printf("\nCouldn't open the device! ... Exiting");
			return -1;
		}
	}
        else
        {
            printf("\nA path to the \"/dev/hidrawX\" is required\n");
        }

	printf("\nMCP2210 demo ended\n");
	return 0;
}

void fill_pattern(uint8_t *pdata, int len)
{
    int idx;
    for(idx = 0; idx < len; idx++)
    {
        pdata[idx] = idx;
    }
}
