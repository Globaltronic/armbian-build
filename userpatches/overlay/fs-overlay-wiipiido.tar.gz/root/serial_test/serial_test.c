// from: between write and read:serial port. - C - http://www.daniweb.com/forums/thread286634.html
// gcc sertest.c -lc -Wall -o sertest

//2019-07-26: Modified test version for better accuracy on loopback

 

/**
* @brief  Program to test Serial port loopback on the A64 Target board
*
* @param argc  => Serial port device
* @param argv[] => Serial port device
*
* @return FD Error
*/
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>




int main(int argc, char *argv[])
{
	
    const char delim[2] = "\r\n";
    char line[1024];
    int chkin;
    char input[1024];
    char msg[1024];
    char serport[24];
    int error_ret = 0;
    int serial_read_status = 0;
    int tryouts = 20;	
    

    char * serial_msg = "123";
	
    // argv[1] - serial port
    // argv[2] - file or echo 

    sprintf(serport, "%s", argv[1]);
	

    int file= open(serport, O_RDWR | O_NOCTTY | O_NDELAY);
    if (file == 0)
    {
        sprintf(msg, "open_port: Unable to open %s.\n", serport);
        perror(msg);
    }

    else
        fcntl(file, F_SETFL, FNDELAY); //fcntl(file, F_SETFL, 0);
	
    do
    {
	// 2019-07-19: Previous code  we fill 
        //printf("enter input data:\n");
        //scanf("%s",&input[0]);
	
	sprintf( input , "%s\r", serial_msg );

        chkin=write(file,input,sizeof input);

	usleep(50000);

        if (chkin<0)
        {
            printf("cannot write to port\n");
        }

        //chkin=read(file,line,sizeof line);

        while ((chkin=read(file,line,sizeof line))>=0)
        {
            if (chkin<0)
            {
                printf("cannot read from port\n");
			
            }
            else
            {
                printf("bytes: %d, line=%s\n",chkin, line);
		
		char * ptr="";

		ptr = strtok(line, delim); // we need to split first the 
		//ptr = strtok(NULL,delim); // we need to split first the 
		//printf("PTR; %s\n", ptr);	
		if (ptr != NULL){

	     	   	if ( (strstr(ptr, serial_msg )) ){ 
				printf("USBUART;%s;OK\n" ,serport  );
				serial_read_status = 1;
				break;
			}
			else{
				serial_read_status = 0;
				//printf("USBUART;%s;KO" , serport  );

			}
		}
		else {
			serial_read_status = 0;
		}
            }
        }

        /*CODE TO EXIT THE LOOP GOES HERE*/
	if(serial_read_status == 1){
		tryouts = -1;
		break;
	}
	//usleep(50000);
	
    }while (--tryouts>1 && serial_read_status == 0);

	if (serial_read_status == 0){
		printf("USBUART;%s;KO" , serport  );
	}

	serial_read_status = 0;

    	close(file);
    	return error_ret;
}



