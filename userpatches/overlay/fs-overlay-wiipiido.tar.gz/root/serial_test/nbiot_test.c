// from: between write and read:serial port. - C - http://www.daniweb.com/forums/thread286634.html
// gcc nbiot_test.c -lc -Wall -o nbiot_test



/**
* @brief  Program to test Serial port to NBIOT module on the A64 Target board
*
* @param argc  => Serial port device
* @param argv[] => Serial port device
*
* @return FD Error
*/
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>



const char delim[2] = "\r\n";

// Basic commands
#define CMD_ATZ "ATZ"
#define CMD_ATE "ATE0"
#define CMD_AT "AT"

// Toggle commands to be tested.
#define SEND_AT


int main(int argc, char *argv[])
{
	
    char line[1024];
    int chkin;
    char input[1024];
    char msg[1024];
    char serport[24];
    int error_ret = 0;
    int serial_read_status = 0;
    int tryouts = 20;
    

	
    // argv[1] - serial port
    // argv[2] - file or echo 
    sprintf(serport, "%s", argv[1]);
	

    int file= open(serport, O_RDWR | O_NOCTTY | O_NDELAY);
    if (file == 0)
    {
        sprintf(msg, "open_port: Unable to open %s.\n", serport);
        perror(msg);
    }

    else
        fcntl(file, F_SETFL, FNDELAY); //fcntl(file, F_SETFL, 0);


    // Send ATZ	
    do
    {
	// 2019-07-19: Previous code  we fill 
        //printf("enter input data:\n");
        //scanf("%s",&input[0]);
	
	sprintf( input , "%s\r", CMD_ATZ );

        chkin=write(file,input,sizeof input);

	usleep(50000);

        if (chkin<0)
        {
            printf("cannot write to port\n");
        }

        //chkin=read(file,line,sizeof line);

        while ((chkin=read(file,line,sizeof line))>=0)
        {
            if (chkin<0)
            {
                printf("cannot read from port\n");
			
            }
            else
            {
                printf("bytes: %d, line=%s\n",chkin, line);

		
		char * ptr;
		ptr = strtok(line, delim); // we need to split first the 
		
		//ptr = strtok(NULL,delim); // we need to split first the 
		if (ptr != NULL){
		

			if ( (strstr(ptr, "OK" )) ){ 
				printf("USBUART;%s;%s;OK\n" , CMD_ATE, serport  );
				serial_read_status = 1;
				break;
			}
			else{
				serial_read_status = 0;
				//printf("USBUART;%s;KO" , serport  );

			}
		}
		else{
			serial_read_status = 0;	
		}	
            }
        }

		

        /*CODE TO EXIT THE LOOP GOES HERE*/
	if(serial_read_status == 1){
		tryouts = -1;
		break;
	}
	//usleep(50000);
	
    }while (--tryouts>1 && serial_read_status == 0);

	if (serial_read_status == 0 ){
		printf("%s;%s;KO" , CMD_ATZ ,  serport  );
	}




    // Send ATE0	
    do
    {
	// 2019-07-19: Previous code  we fill 
        //printf("enter input data:\n");
        //scanf("%s",&input[0]);
	
	sprintf( input , "%s\r", CMD_ATE );

        chkin=write(file,input,sizeof input);

	usleep(50000);

        if (chkin<0)
        {
            printf("cannot write to port\n");
        }

        //chkin=read(file,line,sizeof line);

        while ((chkin=read(file,line,sizeof line))>=0)
        {
            if (chkin<0)
            {
                printf("cannot read from port\n");
			
            }
            else
            {
                printf("bytes: %d, line=%s\n",chkin, line);

		
		char * ptr;
		ptr = strtok(line, delim); // we need to split first the 
		
		//ptr = strtok(NULL,delim); // we need to split first the 
		if (ptr != NULL){
		

			if ( (strstr(ptr, "OK" )) ){ 
				printf("USBUART;%s;%s;OK\n" , CMD_ATE, serport  );
				serial_read_status = 1;
				break;
			}
			else{
				serial_read_status = 0;
				//printf("USBUART;%s;KO" , serport  );

			}
		}
		else{
			serial_read_status = 0;	
		}	
            }
        }

		

        /*CODE TO EXIT THE LOOP GOES HERE*/
	if(serial_read_status == 1){
		tryouts = -1;
		break;
	}
	//usleep(50000);
	
    }while (--tryouts>1 && serial_read_status == 0);

	if (serial_read_status == 0 ){
		printf("%s;%s;KO" , CMD_ATE, serport  );
	}


// Send AT

#ifdef SEND_AT
	tryouts = 20;
   // Send ATE0	
    do
    {
	// 2019-07-19: Previous code  we fill 
        //printf("enter input data:\n");
        //scanf("%s",&input[0]);
	
	sprintf( input , "%s\r", CMD_AT );

        chkin=write(file,input,sizeof input);

	usleep(50000);

        if (chkin<0)
        {
            printf("cannot write to port\n");
        }

        //chkin=read(file,line,sizeof line);

        while ((chkin=read(file,line,sizeof line))>=0)
        {
            if (chkin<0)
            {
                printf("cannot read from port\n");
			
            }
            else
            {
                printf("bytes: %d, line=%s\n",chkin, line);

		
		char * ptr;
		ptr = strtok(line, delim); // we need to split first the 
		
		//ptr = strtok(NULL,delim); // we need to split first the 
		

		if ( (strstr(ptr, "OK" )) ){ 
			printf("USBUART_NBIOT;%s;%s;OK\n" ,CMD_AT,  serport  );
			serial_read_status = 1;
			break;
		}
		else{
			serial_read_status = 0;
			//printf("USBUART;%s;KO" , serport  );

		}

            }
        }

		

        /*CODE TO EXIT THE LOOP GOES HERE*/
	if(serial_read_status == 1){
		tryouts = -1;
		break;
	}
	//usleep(50000);
	
    }while (--tryouts>1 && serial_read_status == 0);

	if ( serial_read_status == 0 ){
		printf("%s;%s;KO" , CMD_AT,  serport  );
	}







#endif


	




    	close(file);
    	return error_ret;
}



int at_cmd(int file,  char * cmd, char * reply ){


   char line[1024];
    int chkin;
    char input[1024];
    char msg[1024];
    int error_ret = 0;
    int serial_read_status = 0;
    int tryouts = 20;


 do
    {
	// 2019-07-19: Previous code  we fill 
        //printf("enter input data:\n");
        //scanf("%s",&input[0]);
	
	sprintf( input , "%s\r", cmd );

        chkin=write(file,input,sizeof input);

	usleep(50000);

        if (chkin<0)
        {
            printf("cannot write to port\n");
	    return -1;
        }

        //chkin=read(file,line,sizeof line);

        while ((chkin=read(file,line,sizeof line))>=0)
        {
            if (chkin<0)
            {
                printf("cannot read from port\n");
		return -2;
			
            }
            else
            {
                printf("bytes: %d, line=%s\n",chkin, line);

		
		char * ptr;
		ptr = strtok(line, delim); // we need to split first the 
		
		//ptr = strtok(NULL,delim); // we need to split first the 
		

     	   	if ( (strstr(ptr, "OK" )) ){ 
			printf("USBUART_NBIOT;%s;OK\n" , cmd );
			serial_read_status = 1;
			break;
		}
		else{
			serial_read_status = 0;
			//printf("USBUART;%s;KO" , serport  );

		}

            }
        }

		

        /*CODE TO EXIT THE LOOP GOES HERE*/
	if(serial_read_status == 1){
		tryouts = -1;
		break;
	}
	//usleep(50000);
	
    }while (--tryouts>1 && serial_read_status == 0);

	if (serial_read_status == 0 ){
		printf("%s;KO" , cmd  );
		return -3;
	}
	


	return 0;
}



