#include <stdio.h>
#include <fcntl.h>
#include <stropts.h>
#include <termios.h>
#include <unistd.h> // to get close() define
#include <time.h>
#include <stdlib.h>


//2019-08-29: implement individual pin mode

// Make sure you have installed the SiLabs's version of cp210x.c driver
// which has these IOCTLs implemented.
#define IOCTL_GPIOGET		0x8000
#define IOCTL_GPIOSET		0x8001

#define CP2108 1
#define CP2108_NGPIOS 16

#define MODE_ALL_STROBE	0
#define MODE_ALL_OFF	1
#define MODE_ALL_ON	2	
#define MODE_WRITE_PIN	3	


void usage();




int main( int argc, char **argv )
{
	int fd;
	int helpopt = 0;
	int c = 0;
	int mode = 0;

	int port = 0;
	int value = 0;

	while( (c = getopt(argc,argv,"m:h:p:v:")) != -1 ){

	switch (c)
	{
		case 'm':		
			mode = atoi(optarg);
		break;
		case 'h':		
			helpopt = 1 ;
		break;

		case 'p':
			port = atoi(optarg);			
	
		break;

		case 'v':
			value = atoi(optarg);			
	
		break;


		default:
			usage();
			return 4;
		break;
	
	}
}


	printf( "CP210x Serial Test\n");
	printf( "Mode :\n" , mode);

	if (mode < 0 || mode > 3){

		usage();
		return 2;
	}

	if(  helpopt  > 0 ){
		usage();
		return 3;
	}

	fd = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd == -1)
	{
		printf( "Error opening port /dev/ttyUSB0\n");
		return 1;
	}
	// mask = 3: gpio #1 and #0; value = 2: set #1, clear #0
	// Clearing GPIO turns LED on on SiLabs blue EK boards.
#ifdef CP2108
	unsigned short gpioread = 0x3333;
	unsigned long gpio = 0x0000FFFF;
#else
	unsigned char gpioread = 0x33;
	unsigned short gpio = 0x0020;
#endif


if (mode != MODE_ALL_OFF && mode != MODE_WRITE_PIN  ){
	ioctl(fd, IOCTL_GPIOGET, &gpioread);
	printf( "gpio read = %x\n", gpioread);


	printf( "gpio to write = %x\n", gpio);
	ioctl(fd, IOCTL_GPIOSET, &gpio);


	sleep(1);
}

if(mode != MODE_ALL_ON && mode != MODE_WRITE_PIN ){
	printf( "gpio to CLEAR write = %x\n", gpio);
	ioctl(fd, IOCTL_GPIOSET, &gpio);

	gpio = 0xFFFFFFFF;
	
	printf( "gpio to SET write = %x\n", gpio);
	ioctl(fd, IOCTL_GPIOSET, &gpio);


	ioctl(fd, IOCTL_GPIOGET, &gpioread);
	printf( "gpio read = %x\n", gpioread);
}


if (mode == MODE_WRITE_PIN) {

	ioctl(fd, IOCTL_GPIOGET, &gpioread);
	printf( "gpio read = %x\n", gpioread);

	if (value ==0 ){	
		gpio =  (unsigned long) (  ((~gpioread) & 0xFFFFFFFF) & ( 0 << (port*CP2108_NGPIOS)  )  | (1<< port) ) ;  		
		gpio = ~gpio;
	}else{
		gpio =  (unsigned long)   ((gpioread & 0xFFFFFFFF) | ( 1 << (port*CP2108_NGPIOS)  ) ) | (1<< port);  		
		
	}

	printf( "gpio to SET write = %x\n", gpio);
	ioctl(fd, IOCTL_GPIOSET, &gpio);


	

}





	close(fd);
	return 0;
	

}




/**
* @brief usage help function
*/
void usage()
{

	printf("cp210x example GPIO Demo\n");
	printf("Usage:\n");
	printf("./cp210x_example [-m mode]");
	printf("0 => Strobe PORTS\n");
	printf("1 => OFF PORTS\n");
	printf("2 => ON PORTS\n");
	printf("3 => WRITE to GPIO\n");
	printf("-h  => this Help\n");
	


}

