#initialize Inputs 

echo 494 > /sys/class/gpio/export
echo 495 > /sys/class/gpio/export
echo 496 > /sys/class/gpio/export
echo 497 > /sys/class/gpio/export
echo 498 > /sys/class/gpio/export
echo 499 > /sys/class/gpio/export
echo 500 > /sys/class/gpio/export
echo 501 > /sys/class/gpio/export
echo 502 > /sys/class/gpio/export
echo 503 > /sys/class/gpio/export
echo 504 > /sys/class/gpio/export
echo 505 > /sys/class/gpio/export
echo 506 > /sys/class/gpio/export
echo 507 > /sys/class/gpio/export
echo 508 > /sys/class/gpio/export
echo 509 > /sys/class/gpio/export



# Test Outputs  to Zero


echo out > /sys/class/gpio/gpio494/direction
echo 0 > /sys/class/gpio/gpio494/value  
echo out > /sys/class/gpio/gpio495/direction
echo 0 > /sys/class/gpio/gpio495/value
echo out > /sys/class/gpio/gpio496/direction
echo 0 > /sys/class/gpio/gpio496/value  
echo out > /sys/class/gpio/gpio497/direction
echo 0 > /sys/class/gpio/gpio497/value
echo out > /sys/class/gpio/gpio498/direction
echo 0 > /sys/class/gpio/gpio498/value  
echo out > /sys/class/gpio/gpio499/direction
echo 0 > /sys/class/gpio/gpio499/value
echo out > /sys/class/gpio/gpio500/direction
echo 0 > /sys/class/gpio/gpio500/value  
echo out > /sys/class/gpio/gpio501/direction
echo 0 > /sys/class/gpio/gpio501/value  


echo out > /sys/class/gpio/gpio502/direction
echo 0 > /sys/class/gpio/gpio502/value  
echo out > /sys/class/gpio/gpio503/direction
echo 0 > /sys/class/gpio/gpio503/value
echo out > /sys/class/gpio/gpio504/direction
echo 0 > /sys/class/gpio/gpio504/value  
echo out > /sys/class/gpio/gpio505/direction
echo 0 > /sys/class/gpio/gpio505/value
echo out > /sys/class/gpio/gpio506/direction
echo 0 > /sys/class/gpio/gpio506/value  
echo out > /sys/class/gpio/gpio507/direction
echo 0 > /sys/class/gpio/gpio507/value
echo out > /sys/class/gpio/gpio508/direction
echo 0 > /sys/class/gpio/gpio508/value  
echo out > /sys/class/gpio/gpio509/direction
echo 0 > /sys/class/gpio/gpio509/value  


# Test Outputs  to One


echo out > /sys/class/gpio/gpio494/direction
echo 1 > /sys/class/gpio/gpio494/value  
echo out > /sys/class/gpio/gpio495/direction
echo 1 > /sys/class/gpio/gpio495/value
echo out > /sys/class/gpio/gpio496/direction
echo 1 > /sys/class/gpio/gpio496/value  
echo out > /sys/class/gpio/gpio497/direction
echo 1 > /sys/class/gpio/gpio497/value
echo out > /sys/class/gpio/gpio498/direction
echo 1 > /sys/class/gpio/gpio498/value  
echo out > /sys/class/gpio/gpio499/direction
echo 1 > /sys/class/gpio/gpio499/value
echo out > /sys/class/gpio/gpio500/direction
echo 1 > /sys/class/gpio/gpio500/value  
echo out > /sys/class/gpio/gpio501/direction
echo 1 > /sys/class/gpio/gpio501/value  


echo out > /sys/class/gpio/gpio502/direction
echo 1 > /sys/class/gpio/gpio502/value  
echo out > /sys/class/gpio/gpio503/direction
echo 1 > /sys/class/gpio/gpio503/value
echo out > /sys/class/gpio/gpio504/direction
echo 1 > /sys/class/gpio/gpio504/value  
echo out > /sys/class/gpio/gpio505/direction
echo 1 > /sys/class/gpio/gpio505/value
echo out > /sys/class/gpio/gpio506/direction
echo 1 > /sys/class/gpio/gpio506/value  
echo out > /sys/class/gpio/gpio507/direction
echo 1 > /sys/class/gpio/gpio507/value
echo out > /sys/class/gpio/gpio508/direction
echo 1 > /sys/class/gpio/gpio508/value  
echo out > /sys/class/gpio/gpio509/direction
echo 1 > /sys/class/gpio/gpio509/value  







# Test inputs 

 

echo in > /sys/class/gpio/gpio494/direction
cat  /sys/class/gpio/gpio494/value  
echo in > /sys/class/gpio/gpio495/direction
cat  /sys/class/gpio/gpio495/value
echo in > /sys/class/gpio/gpio496/direction
cat  /sys/class/gpio/gpio496/value  
echo in > /sys/class/gpio/gpio497/direction
cat  /sys/class/gpio/gpio497/value
echo in > /sys/class/gpio/gpio498/direction
cat  /sys/class/gpio/gpio498/value  
echo in > /sys/class/gpio/gpio499/direction
cat  /sys/class/gpio/gpio499/value
echo in > /sys/class/gpio/gpio500/direction
cat  /sys/class/gpio/gpio500/value  
echo in > /sys/class/gpio/gpio501/direction
cat  /sys/class/gpio/gpio501/value  


echo in > /sys/class/gpio/gpio502/direction
cat  /sys/class/gpio/gpio502/value  
echo in > /sys/class/gpio/gpio503/direction
cat  /sys/class/gpio/gpio503/value
echo in > /sys/class/gpio/gpio504/direction
cat  /sys/class/gpio/gpio504/value  
echo in > /sys/class/gpio/gpio505/direction
cat  /sys/class/gpio/gpio505/value
echo in > /sys/class/gpio/gpio506/direction
cat  /sys/class/gpio/gpio506/value  
echo in > /sys/class/gpio/gpio507/direction
cat  /sys/class/gpio/gpio507/value
echo in > /sys/class/gpio/gpio508/direction
cat  /sys/class/gpio/gpio508/value  
echo in > /sys/class/gpio/gpio509/direction
cat  /sys/class/gpio/gpio509/value  


 
