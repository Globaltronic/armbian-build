Log
---------------------------------------------------------------------------------------

2019-09-05:

	Added stable version 0.1 with 32 bit write / 16 bit read latch support


Instructions:
---------------------------------------------------------------------------------------

- Compile : 
	make all

- Install:

	sudo cp cp210x_gpio.ko /lib/modules/$(uname -r)/kernel/drivers/usb/serial/cp210x.ko
	sudo rmmod cp210x_gpio
	sudo modprobe cp210x
 - Clean:

	make clean

- Test:

	Use the contents of the script cp2108_gpio_sysfs_init.sh to test inputs / outputs by copy paste the corresponding blocks
