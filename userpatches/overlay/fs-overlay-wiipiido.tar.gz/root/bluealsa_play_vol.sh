#!/bin/bash

# Auth: Globaltronic
# check available Simple control volume for Bluealsa and adjust volume

# command: amixer -D bluealsa scontrols  | sed -nr "s/(.*)('(.*)A2DP')(.*)/\2/pg"
a2dp_control=`amixer -D bluealsa scontrols | sed -nr "s/(.*)('((.*)A2DP)')(.*)/\3/pg"`

vol_adj=$1 

usage () {
	echo "Usage:"
	echo "$(basename $0) vol_adj"
	echo "vol_adj { 0 - 100}"
}

if [ "$a2dp_control" != "" ]; then
	echo "Found simple control: $a2dp_control"
	eval echo -e $(amixer -D bluealsa sset 	"${a2dp_control}" ${vol_adj}%)
	#eval echo -e $(amixer -D bluealsa sset '6826150 - A2DP' ${vol_adj}%)
else
	echo "Error no bluealsa running or bad control"
	exit 1
fi


\
