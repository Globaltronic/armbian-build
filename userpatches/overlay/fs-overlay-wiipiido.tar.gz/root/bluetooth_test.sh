#!/bin/bash

#Bluetooth test Script
#2020-02-2020 TODO: Remove only if no bluealsa is installed 

BLE_MACCADDR="86:99:76:57:0C:33"

echo "0.1" > /tmp/version_$(basename $0) 


usage(){
	echo "Bluetooth Test Script"
	echo "$(basename $0) [options]"
	echo " -l / --list: Scan/List Devices Only  "
	echo " -p / --pair <MAC>:  Pair Device Only  "
	echo "-a / --all <>: Test Scan + Pair"
}


if [ "$1" == "" ]; then
	usage
fi

# Validate Bluetooth MAC Address
if [ "$2" != "" ]; then
	bl_macaddr=$2

	bl_macaddr_st=`echo $bl_macaddr | sed -nr "s/\r//;s/((([0-9A-F]{2}\:){5})[0-9A-F]{2})/\1/gp"`
	
	# if valid MAC ADDR supplied is supplied then override the default one 
	if [ "$bl_macaddr_st" == "" ]; then
		echo "Invalid MAC Address Format "
		echo "Please list one MAC Address with -l or --List Otions, eg 	\'AA:AA:AA:AA:AA:AA\'" 
		exit 5
	else
		BLE_MACCADDR=$bl_macaddr
	fi
fi


# TODO: Add regex to snatch the Master BLEMAC ADDR , Done
bl_devinfo=`hcitool dev | sed -nr "s/\r//;s/(\s+)(hci[0-9]\s+((([0-9A-F]{2}\:){5})[0-9A-F]{2}))(.*)/\3/gp"`

if [ "$bl_devinfo" == "" ]; then 
	echo "Error no BLE master or hcitool installed"
	echo "Attempt power cycle"
	
	bl_pwr_st=`echo -e "power off\n" | bluetoothctl`
	sleep 2
	bl_pwr_st=`echo -e "power on\n" | bluetoothctl`
	sleep 2

	exit 1
fi




bl_status=`echo $bl_devinfo || OK` 
echo "BLE status: ${bl_status}"



# Get Scan status
let tryouts=10
while [ "$tryouts" != "0" ]; 
do

	
	# override scan connection - go to pair
	if [ "$1" == "-p" ] || [ "$1" == "--pair" ]; then
		bl_agent_flag="1"
		break
	fi
	 
	echo "Toggle Bluetooth power..."
	bl_pwr_st=`echo -e "power off\n" | bluetoothctl`
	sleep 2
	bl_pwr_st=`echo -e "power on\n" | bluetoothctl`
	sleep 2

	bl_agent=`echo -e "agent on\nexit" | bluetoothctl`
	let tryouts=$(( tryouts - 1 ))

	#bl_agent_st=`echo $bl_agent | grep -E "Agent  registered"`
	bl_agent_st=`echo $bl_agent | grep -E "Agent is already registered"`
	if [ "$bl_agent_st" != "" ]; then
		
		# issue default agent command
		bl_defn_agent=`echo -e "default-agent\n" | bluetoothctl`
		echo "Agent default Status: ${bl_defn_agent}"
		bl_agent_flag="1"
		break
	else 
		bl_agent_flag="0"
	fi		

	sleep 1
done


echo "BLE Agent Status: $bl_agent"


# TODO: check controller availability 

echo "List Bluetooth Controller..."
bl_list=`echo -e "list\n" | bluetoothctl`
sleep 2



echo "Show Bluetooth Controller..."
bl_show=`echo -e "show\n" | bluetoothctl`
sleep 2

bl_dev_macaddr=`echo ${bl_show} | sed -nr "s/\r//;s/(.*)Controller\s+((([0-9A-F]{2}\:){5})[0-9A-F]{2})(.*)/\2/pg"`
echo "Bluetooth Controler Mac Address : ${bl_dev_macaddr}"


if [ "$bl_dev_macaddr" != "" ] && [ "$bl_devinfo" == "$bl_dev_macaddr" ]; then

	echo "Toggle Bluetooth Controller..."
	#bl_select=`echo -e "select ${bl_devinfo}\n" | bluetoothctl`
	bl_select=`echo -e "select ${bl_dev_macaddr}\n" | bluetoothctl`
	sleep 2
else
	echo "Error: No Default Bluetooth Controller Available. Master KO"
	echo "Re-Power unit"
	exit 6
fi

bl_select_st=`echo $bl_select | grep -E "Controller ${bl_devinfo} not available"`

if [ "$bl_select_st" != "" ]; then
	echo "Bluetooth Host Controller not Found"
	exit 7
fi



# List all devices
echo "BLE Agent Status: $bl_agent"
let tryouts=10
while [ "$tryouts" != "0" ]; 
do 
	
	echo "Scanning... Power Cycle the Bluetooth device"
	#bl_scan_st=`echo -e "scan off\n" | bluetoothctl`
	#sleep 5
	bl_scan_st=`echo -e "scan on\n" | bluetoothctl`
	sleep 15
	bl_devices=`echo -e "devices\n" | bluetoothctl`
	sleep 2
	let tryouts=$(( tryouts - 1 ))

	#echo "Scanning..."
	#bl_devices=`echo -e "scan off\nscan on\ndevices\n" | bluetoothctl`
	#sleep 15
	echo "Devices List[ $tryouts ]: ${bl_devices}"

	bl_devices_st=`echo $bl_devices | grep -E "${BLE_MACCADDR}"`


	if [ "$bl_devices_st" != "" ]; then
		bl_devices_flag="1"
		break
	else
		echo "Toggle Bluetooth power..."
		bl_pwr_st=`echo -e "power off\n" | bluetoothctl`
		sleep 5
		bl_pwr_st=`echo -e "power on\n" | bluetoothctl`
		sleep 5
		bl_devices_flag="0"
	fi

	sleep 1
done


echo "BLE Device Found: ${bl_devices_st}"

if [ "$1" == "-l" ] || [ "$1" == "--list" ]; then
	echo "Scan Only Mode Complete"
	echo "Please Choose one Device"
	exit 0
elif [ "$1" == "-a" ] || [ "$1" == "--all" ]; then
	echo "Selected Option -a or --all. Now pairing"
else
	usage
	exit 2 
fi


if [ "$bl_devices_flag" == "1" ]; then

	bl_trust=`echo -e "trust ${BLE_MACCADDR}\n" | bluetoothctl`
	bl_trust_st=`echo ${bl_trust} | grep -E "Changing ${BLE_MACCADDR} trust succeeded)"`
	sleep 1



	# Pair to specific device
	bl_pair=`echo -e "pair ${BLE_MACCADDR}\n" | bluetoothctl`
	sleep 1


	# Get Info from device	
	let tryouts=50
	while [ "$tryouts" != "0" ]; 
	do
#		bl_pair=`echo -e "pair ${BLE_MACCADDR}\n" | bluetoothctl`
#		sleep 2
 
		bl_info=`echo -e "info ${BLE_MACCADDR}\nexit" | bluetoothctl`
		let tryouts=$(( tryouts - 1 ))
	
		bl_info_st=`echo $bl_info | grep -E "Paired: yes"`
		
		if [ "$bl_info_st" != "" ]; then
			bl_conn_flag="1"
			break
		else
			bl_conn_flag="0"
		fi
	
		# Check existent paired device and skip if it is
		bl_pair_st=`echo $bl_pair | grep -E "Failed to pair: org.bluez.Error.AlreadyExists"`
		if [ "$bl_pair_st" != "" ]; then
			bl_pair_flag="1"
			bl_conn_flag="1"
			break
		else
			bl_pair_flag="0"
		fi

		bl_pair=`echo -e "pair ${BLE_MACCADDR}\n" | bluetoothctl`
		sleep 2
 
		#bl_info=`echo -e "info ${BLE_MACCADDR}\nexit" | bluetoothctl`
		#let tryouts=$(( tryouts - 1 ))
	
		#bl_info_st=`echo $bl_pair | grep -E "Paired: yes"`
				
		#if [ "$bl_info_st" != "" ]; then
		#	bl_conn_flag="1"
		#	break
		#else
		#	bl_conn_flag="0"
		#fi
	
		sleep 1
	done

else
	echo "No Paired Devices "
	exit 3
fi


#TODO: Add Pairable Mode and Trusted connection	
if [ "$bl_conn_flag" == "1" ]; then
	echo "Device Connection in progress...Finished"

	# Trust device
	bl_trust=`echo -e "trust ${BLE_MACCADDR}\n" | bluetoothctl`
	bl_trust_st=`echo ${bl_trust} | grep -E "Changing ${BLE_MACCADDR} trust succeeded)"`
	sleep 1

	#Turn on Pairable mode - 3 minutes to live
	bl_pairable=`echo -e "pairable on\n" | bluetoothctl`
	bl_pairable_st=`echo ${bl_pairable} | grep -E "Changing pairable on succeeded"`
	sleep 3

	# Connect  to device with no pin ( Bluetooth Speaker)
	bl_connect=`echo -e "connect ${BLE_MACCADDR}\n" | bluetoothctl`
	sleep 1

	echo "Bluetooth Connection Host[ ${bl_dev_macaddr} ] \<\=\> Dev[ ${bl_connect} ] = ${bl_connect} "
	#	let tryouts=10
#	while [ "$tryouts" != "0" ]; 
#	do 
#		bl_remove=`echo -e "remove ${BLE_MACCADDR}\n" | bluetoothctl`
#		sleep 1
#		let tryouts=$(( tryouts - 1 ))
#		
#		bl_remove_st=`echo $bl_remove | grep -E "Device has been removed"`
#		bl_remove_st=`echo $bl_remove | grep -E "Device ${BLE_MACCADDR} not available"` 
#
#		if [ "$bl_remove_st" != "" ]; then
#			bl_remove=`echo -e "exit\n" | bluetoothctl`
#			bl_remove_st="1"
#			break
#		else
#			bl_remove_st="0"
#		fi
#		
#		sleep 1	
#	done
	
	bl_connec_st=`echo $bl_connect | grep -E "Connection successful"` 
		
	#
	#MEssage: Changing 86:99:76:57:0C:33 trust succeeded
	# MEssage: Changing pairable on succeeded	

	#2020-02-2020 : Remove only if no bluealsa is installed 

	bl_remove="1" 
#	let tryouts=10
#	while [ "$tryouts" != "0" ]; 
#	do 
#		bl_remove=`echo -e "remove ${BLE_MACCADDR}\n" | bluetoothctl`
#		sleep 1
#		let tryouts=$(( tryouts - 1 ))
#		
#		bl_remove_st=`echo $bl_remove | grep -E "Device has been removed"`
#		bl_remove_st=`echo $bl_remove | grep -E "Device ${BLE_MACCADDR} not available"` 
#
#		if [ "$bl_remove_st" != "" ]; then
#			bl_remove=`echo -e "exit\n" | bluetoothctl`
#			bl_remove_st="1"
#			break
#		else
#			bl_remove_st="0"
#		fi
#		
#		sleep 1	
#	done
		
	echo "BLE Removal Status: $bl_remove"

	# TODO: Check if device is properly paired 
	# Paired: no
	


else 
	echo "Device Connection [Failed]"
	exit 4
fi
